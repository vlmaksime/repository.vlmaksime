# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from resources.libs import (iTV, iTVError,
                            ChannelInfo, MovieInfo, TVShowInfo, SeasonInfo, EpisodeInfo, FootballInfo,
                            IslomInfo, MusicInfo, PressInfo,
                            EmptyListItem, ListItem)

import xbmc
import xbmcplugin
import simplemedia

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()


# ProductInfo.plugin = plugin
# EmptyListItem.plugin = plugin


@plugin.route('/login')
def login():
    _login = plugin.get_keyboard_text('', _('Enter your login'))
    if _login:

        xbmc.sleep(1000)

        _password = plugin.get_keyboard_text('', _('Enter your password'), True)
        if _password:
            try:
                api = iTV()
                login_result = api.login(_login, _password)
            except (iTVError, simplemedia.WebClientError) as e:
                plugin.notify_error(e, True)
            else:
                try:
                    user_info = api.user_info()
                except (iTVError, simplemedia.WebClientError) as e:
                    plugin.notify_error(e, True)
                else:
                    user_fields = api.get_user_fields(user_info['data']['balance'])
                    plugin.set_settings(user_fields)

                plugin.dialog_ok(login_result['message'])


@plugin.route('/logout')
def logout():
    api = iTV()
    api.logout()
    user_fields = api.get_user_fields()
    plugin.set_settings(user_fields)

    plugin.dialog_ok(_('You have successfully logged out'))


@plugin.route('/')
def root():
    plugin.create_directory(_root_list(), content='', category=plugin.name)


def _root_list():

    for item in _catalog_items():

        url = plugin.url_for('catalog', catalog_id=item['id'])
        list_item = {'label': item['name'],
                     'url': url,
                     'icon': item['icon'],
                     'fanart': plugin.fanart,
                     'is_folder': True,
                     'is_playble': False,
                     'content_lookup': False,
                     }
        yield list_item

    url = plugin.url_for('search_history')
    list_item = {'label': _('Search'),
                 'url': url,
                 'icon': plugin.get_image('DefaultAddonsSearch.png'),
                 'fanart': plugin.fanart,
                 'is_folder': True,
                 'is_playble': False,
                 'content_lookup': False,
                 }
    yield list_item


def _catalog_items():
    # icons
    movie_icon = plugin.get_image('DefaultMovies.png')
    musicvideos_icon = plugin.get_image('DefaultMusicVideos.png')
    tvshow_icon = plugin.get_image('DefaultTVShows.png')
    pvr_icon = plugin.get_image('DefaultAddonPVRClient.png')
    favirote_icon = plugin.get_image('DefaultFavourites.png')

    # sort methods
    default_sort_method = {'sortMethod': xbmcplugin.SORT_METHOD_UNSORTED, 'label2Mask': '%Y / %O'}
    musicvideos_sort_method = {'sortMethod': xbmcplugin.SORT_METHOD_UNSORTED, 'label2Mask': '%Y'}

    yield {'id': 'channels',
           'name': _('TV Channels'),
           'icon': pvr_icon,
           'sort_method': default_sort_method,
           'content': 'videos',
           'method': 'channels',
           }

    yield {'id': 'movies',
           'name': _('Movies'),
           'icon': movie_icon,
           'sort_method': default_sort_method,
           'content': 'movies',
           'method': 'movies',
           }

    yield {'id': 'tvshows',
           'name': _('TV Shows'),
           'icon': tvshow_icon,
           'sort_method': default_sort_method,
           'content': 'tvshows',
           'method': 'movies',
           'params': {'tvshow': 1},
           }

    yield {'id': 'amediateka',
           'name': 'Amediateka',
           'icon': movie_icon,
           'sort_method': default_sort_method,
           'content': 'movies',
           'method': 'movies',
           'params': {'amediateka': 1},
           }

    yield {'id': 'cartoons',
           'name': _('Cartoons'),
           'icon': movie_icon,
           'sort_method': default_sort_method,
           'content': 'movies',
           'method': 'movies',
           'params': {'cartoon': 1},
           }

    yield {'id': 'uzbek',
           'name': _('Uzbek'),
           'icon': movie_icon,
           'sort_method': default_sort_method,
           'content': 'movies',
           'method': 'movies',
           'params': {'uzb': 1},
           }

    yield {'id': 'education',
           'name': 'Online education',
           'icon': movie_icon,
           'sort_method': default_sort_method,
           'content': 'movies',
           'method': 'movies',
           'params': {'education': 1},
           }

    yield {'id': 'concerts',
           'name': _('Concerts'),
           'icon': musicvideos_icon,
           'sort_method': musicvideos_sort_method,
           'content': 'videos',
           'method': 'music',
           'params': {'is_concert': 1},
           }

    yield {'id': 'football',
           'name': _('Football'),
           'icon': tvshow_icon,
           'sort_method': default_sort_method,
           'content': 'videos',
           'method': 'football',
           }

    yield {'id': 'islom',
           'name': _('Muslim'),
           'icon': tvshow_icon,
           'sort_method': default_sort_method,
           'content': 'videos',
           'method': 'islom',
           }

    yield {'id': 'press',
           'name': _('Press'),
           'icon': tvshow_icon,
           'sort_method': default_sort_method,
           'content': 'videos',
           'method': 'press',
           }

    yield {'id': 'music',
           'name': _('Music'),
           'icon': musicvideos_icon,
           'sort_method': musicvideos_sort_method,
           'content': 'videos',
           'method': 'music',
           }


@plugin.route('/catalog/<catalog_id>/')
def catalog(catalog_id):
    catalog_info = _catalog_info(catalog_id)

    page = plugin.params.page or '1'
    page = int(page)

    limit = plugin.params.limit
    if not limit:
        limit = plugin.get_setting('limit', False)
    limit = int(limit)

    catalog_params = catalog_info.get('params') or {}

    catalog_method = catalog_info['method']

    if catalog_info['method'] == 'movies':
        if plugin.get_setting('filter_3d'):
            catalog_params['is3d'] = 1
        if plugin.get_setting('filter_4k'):
            catalog_params['is4k'] = 1
        if plugin.get_setting('filter_hd'):
            catalog_params['hd'] = 1


    try:
        catalog_result = _catalog_content(catalog_info['method'], page=page, items=limit, **catalog_params)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:
        page_params = {'catalog_id': catalog_id,
                       }

        pages = _get_pages(page_params, page, catalog_result['items_per_page'], catalog_result['total_items'],
                           'catalog')

        category_parts = [catalog_info['name'],
                          '{0} {1}'.format(_('Page'), page)
                          ]
        # if cat_info['id'] == 'history':
        #     items = _list_history(category_result['results'], pages)
        # else:
        items = _list_catalog(catalog_info, catalog_result, pages)

        result = {'items': items,
                  'total_items': len(catalog_result['list']),
                  'content': catalog_info['content'],
                  'category': ' / '.join(category_parts),
                  'sort_methods': catalog_info['sort_method'],
                  'update_listing': (page > 1),
                  }
        plugin.create_directory(**result)


def _list_catalog(catalog_info, catalog_result, pages):
    catalog_id = catalog_info['id']
    catalog_method = catalog_info['method']

    use_atl_names = _use_atl_names()

    api = iTV()

    for item in catalog_result['list']:
        if catalog_method == 'channels':
            video_info = ChannelInfo(item)
        elif catalog_method in ['movies', 'search']:
            item_info = api.movie_info(item['id'])
            if item_info['is_tvshow'] == 1:
                video_info = TVShowInfo(item_info)
            else:
                video_info = MovieInfo(item_info)
        elif catalog_method == 'football':
            video_info = FootballInfo(item)
        elif catalog_method == 'islom':
            video_info = IslomInfo(item)
        elif catalog_method == 'press':
            video_info = PressInfo(item)
        elif catalog_method == 'music':
            video_info = MusicInfo(item)

        listitem = ListItem(video_info)

        url = _get_listitem_url(catalog_info, video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()

    if pages is not None:
        for listitem in _page_items(pages):
            yield listitem


def _catalog_content(catalog_id, **kwargs):
    api = iTV()
    method_name = '{0}_list'.format(catalog_id)
    return getattr(api, method_name)(**kwargs)


@plugin.route('/catalog/tvshows/<tvshow_id>/')
def tvshow_seasons(tvshow_id):
    api = iTV()
    try:
        seasons_result = api.seasons_list(tvshow_id)
        tvshow_info = api.movie_info(tvshow_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:

        result = {'items': _list_seasons(tvshow_info, seasons_result['list']),
                  'total_items': seasons_result['total_items'],
                  'content': 'seasons',
                  'category': tvshow_info['title'],
                  'sort_methods': xbmcplugin.SORT_METHOD_UNSORTED,
                  }
        plugin.create_directory(**result)


def _list_seasons(tvshow_info, season_items):
    use_atl_names = _use_atl_names()

    catalog_info = {'id': 'seasons',
                    'method': 'movies'}

    for season_item in season_items:
        video_info = SeasonInfo(tvshow_info, season_item)
        listitem = ListItem(video_info)

        url = _get_listitem_url(catalog_info, video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()


@plugin.route('/catalog/tvshows/<tvshow_id>/<season_id>/')
def tvshow_episodes(tvshow_id, season_id):
    api = iTV()
    try:
        episodes_result = api.episodes_list(tvshow_id, season_id)
        tvshow_info = api.movie_info(tvshow_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:

        if _use_atl_names():
            sorth_method = xbmcplugin.SORT_METHOD_UNSORTED
        else:
            sorth_method = xbmcplugin.SORT_METHOD_EPISODE

        result = {'items': _list_episodes(tvshow_info, episodes_result['list']),
                  'total_items': episodes_result['total_items'],
                  'content': 'episodes',
                  'category': '/'.join([tvshow_info['title'], '{0} {1}'.format(_('Season'), season_id)]),
                  'sort_methods': sorth_method,
                  }
        plugin.create_directory(**result)


def _list_episodes(tvshow_info, episode_items):
    use_atl_names = _use_atl_names()

    catalog_info = {'id': 'episodes',
                    'method': 'movies'}

    for episode_item in episode_items:
        video_info = EpisodeInfo(tvshow_info, episode_item)
        listitem = ListItem(video_info)

        url = _get_listitem_url(catalog_info, video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()


@plugin.route('/catalog/channels/<channel_id>/')
def play_channel(channel_id):
    try:
        api = iTV()
        channel_result = api.channel_info(channel_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = ChannelInfo(channel_result)
        listitem = ListItem(video_info)
        url = channel_result['source_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/movies/<movie_id>/')
def play_movie(movie_id):
    try:
        api = iTV()
        movie_result = api.movie_info(movie_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = MovieInfo(movie_result)
        listitem = ListItem(video_info)
        url = movie_result['video_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/football/<football_id>/')
def play_football(football_id):
    try:
        api = iTV()
        football_result = api.movie_info(football_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = FootballInfo(football_result)
        listitem = ListItem(video_info)
        url = football_result['video_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/islom/<islom_id>/')
def play_islom(islom_id):
    try:
        api = iTV()
        islom_result = api.islom_info(islom_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = IslomInfo(islom_result)
        listitem = ListItem(video_info)
        url = islom_result['video_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/press/<press_id>/')
def play_press(press_id):
    try:
        api = iTV()
        press_result = api.press_info(press_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = PressInfo(press_result)
        listitem = ListItem(video_info)
        url = press_result['video_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/music/<music_id>/')
def play_music(music_id):
    try:
        api = iTV()
        music_result = api.music_info(music_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
    else:
        succeeded = True

        video_info = FootballInfo(music_result)
        listitem = ListItem(video_info)
        url = music_result['video_url']
        listitem.set_path(url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/catalog/tvshows/<tvshow_id>/<season_id>/<int:episode_id>/')
def play_episode(tvshow_id, season_id, episode_id):

    listitem = EmptyListItem()
    succeeded = False

    api = iTV()
    try:
        episodes_result = api.episodes_list(tvshow_id, season_id)
        tvshow_info = api.movie_info(tvshow_id)
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
    else:

        for episode_item in episodes_result['list']:
            if episode_item['id'] == episode_id:
                video_info = EpisodeInfo(tvshow_info, episode_item)
                listitem = ListItem(video_info)
                listitem.set_path(episode_item['video_url'])
                succeeded = True
                break

    plugin.resolve_url(listitem.get_item(), succeeded)

def _get_pages(page_params, page, limit, total, action):
    # Parameters for previous page
    if page > 1:
        _prev_page = page - 1
        if _prev_page > 1:
            prev_page = {'page': _prev_page,
                         'limit': limit,
                         }
            prev_page.update(page_params)
        else:
            prev_page = page_params
    else:
        prev_page = None

    # Parameters for next page
    if total > (page * limit):
        next_page = {'page': page + 1,
                     'limit': limit,
                     }
        next_page.update(page_params)
    else:
        next_page = None

    pages = {'action': action,
             'prev': prev_page,
             'next': next_page,
             }

    return pages


@plugin.route('/search/history/')
def search_history():
    result = {'items': plugin.search_history_items(),
              'content': '',
              'category': ' / '.join([plugin.name, _('Search')]),
              }

    plugin.create_directory(**result)


@plugin.route('/search/remove/<int:index>')
def search_remove(index):
    plugin.search_history_remove(index)


@plugin.route('/search/clear')
def search_clear():
    plugin.search_history_clear()


@plugin.route('/search/')
def search():
    keyword = plugin.params.keyword or ''
    usearch = plugin.params.usearch or ''
    is_usearch = (usearch.lower() == 'true')

    if not keyword:
        keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
                and not is_usearch:
            plugin.update_search_history(keyword)

            url = plugin.url_for('search', keyword=keyword)
            xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword is not None:

        catalog_info = {'id': 'search',
                        'method': 'search'}

        page = plugin.params.page or '1'
        page = int(page)

        limit = plugin.params.limit
        if not limit:
            limit = plugin.get_setting('limit', False)
        limit = int(limit)

        try:
            catalog_result = _catalog_content(catalog_info['method'], word=keyword, page=page, items=limit)
        except (iTVError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:
            page_params = {'keyword': keyword,
                           }

            pages = _get_pages(page_params, page, catalog_result['items_per_page'], catalog_result['total_items'],
                               'search')

            category_parts = [_('Search'), keyword,
                              '{0} {1}'.format(_('Page'), page)
                              ]
            items = _list_catalog(catalog_info, catalog_result, pages)

            result = {'items': items,
                      'total_items': len(catalog_result['list']),
                      'content': 'movies',
                      'category': ' / '.join(category_parts),
                      'sort_methods': xbmcplugin.SORT_METHOD_UNSORTED,
                      'update_listing': (page > 1),
                      }
            plugin.create_directory(**result)


@plugin.route('/iptv/channels')
def iptv_channels():
    try:
        catalog_result = _catalog_content('channels')
    except (iTVError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:
        from resources.libs.iptv import IPTVManager

        port = int(plugin.params.port)
        IPTVManager(port).send_channels(_iptv_channels_items(catalog_result))


def _iptv_channels_items(catalog_result):
    catalog_info = _catalog_info('channels')

    for item in catalog_result['list']:
        video_info = ChannelInfo(item)
        result = {'id': 'itv-uz-{0}'.format(video_info.id),
                  'label': video_info.title,
                  'logo': video_info.get_poster(),
                  'url': _get_listitem_url(catalog_info, video_info)}
        yield result


def _use_atl_names():
    return plugin.params.get('atl', '') == '1' \
           or plugin.get_setting('use_atl_names')


def _get_listitem_url(catalog_info, video_info, use_atl_names=False):
    catalog_id = catalog_info['id']
    catalog_method = catalog_info['method']

    ext_dir_params = {}
    ext_item_params = {}

    if use_atl_names:
        ext_dir_params['atl'] = 1
        ext_item_params['strm'] = 1

    if isinstance(video_info, ChannelInfo):
        url = plugin.url_for('play_channel', channel_id=video_info.id)
    elif isinstance(video_info, EpisodeInfo):
        url = plugin.url_for('play_episode', tvshow_id=video_info.id, season_id=video_info.season_id,
                             episode_id=video_info.episode_id, **ext_item_params)
    elif isinstance(video_info, SeasonInfo):
        url = plugin.url_for('tvshow_episodes', tvshow_id=video_info.id, season_id=video_info.season_id, **ext_item_params)
    elif isinstance(video_info, TVShowInfo):
        url = plugin.url_for('tvshow_seasons', tvshow_id=video_info.id, **ext_item_params)
    elif isinstance(video_info, MovieInfo):
        url = plugin.url_for('play_movie', movie_id=video_info.id, **ext_item_params)
    elif isinstance(video_info, FootballInfo):
        url = plugin.url_for('play_football', football_id=video_info.id, **ext_item_params)
    elif isinstance(video_info, IslomInfo):
        url = plugin.url_for('play_islom', islom_id=video_info.id, **ext_item_params)
    elif isinstance(video_info, PressInfo):
        url = plugin.url_for('play_press', press_id=video_info.id, **ext_item_params)
    elif isinstance(video_info, MusicInfo):
        url = plugin.url_for('play_music', music_id=video_info.id, **ext_item_params)

    return url


def _page_items(pages):
    if pages['prev'] is not None:
        url = plugin.url_for(pages['action'], **pages['prev'])
        listitem = {'label': _('Previous page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem

    if pages['next'] is not None:
        url = plugin.url_for(pages['action'], **pages['next'])
        listitem = {'label': _('Next page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem


def _catalog_info(catalog_id):
    for item in _catalog_items():
        if catalog_id == item['id']:
            return item


def _page_items(pages):
    if pages['prev'] is not None:
        url = plugin.url_for(pages['action'], **pages['prev'])
        listitem = {'label': _('Previous page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem

    if pages['next'] is not None:
        url = plugin.url_for(pages['action'], **pages['next'])
        listitem = {'label': _('Next page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem


if __name__ == '__main__':
    plugin.run()
