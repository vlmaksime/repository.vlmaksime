# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import platform

from future.utils import PY3
from future.utils import iteritems
from datetime import datetime, timedelta
import os
import xbmc
import simplemedia
import time

from .itv import iTVClient, iTVError

__all__ = ['iTVClient', 'iTVError',
           'ChannelInfo', 'MovieInfo', 'TVShowInfo', 'SeasonInfo', 'FootballInfo', 'EpisodeInfo',
           'IslomInfo', 'MusicInfo', 'PressInfo',
           'EmptyListItem', 'ListItem']

addon = simplemedia.Addon()


class iTV(iTVClient):

    def __init__(self):

        super(iTV, self).__init__()

        headers = self._client.headers
        if addon.kodi_major_version() >= '17':
            headers['User-Agent'] = xbmc.getUserAgent()

        cookie_file = os.path.join(addon.profile_dir, 'itv.cookies')

        self._client = simplemedia.WebClient(headers, cookie_file)
        # self._client.verify = False
        self.check_device()

    def check_device(self):

        device_id = addon.get_setting('device_id')
        if not device_id:
            device_id = self.device_id()
            addon.set_setting('device_id', device_id)

        mem_device_info = addon.get_mem_storage('device_info')
        if mem_device_info.get('devise_os') is None:
            os_name = platform.system()
            if os_name == 'Linux':
                if xbmc.getCondVisibility('system.platform.android'):
                    os_name = 'Android'
            else:
                os_name = '{0} {1}'.format(os_name, platform.release())

            mem_device_info['devise_os'] = os_name

        if mem_device_info.get('devise_brand') is None:
            mem_device_info['devise_brand'] = 'Kodi {0}_{1}'.format(addon.kodi_version(), device_id[-5:])


        devise_os = mem_device_info['devise_os']
        devise_brand = mem_device_info['devise_brand']
        self.set_device_info(device_id, devise_os, devise_brand)

    def check_user(self):
        try:
            user_info = self.user_info()
        except (iTVError, simplemedia.WebClientError) as e:
            addon.notify_error(e)
        else:
            user_fields = self.get_user_fields(user_info['data']['balance'])
            addon.set_settings(user_fields)

    def logout(self):

        token_info = addon.get_mem_storage('token')
        if token_info.get('token') is not None \
          and token_info['info'].get('user_id') is not None:
            del token_info['info']['user_id']
            token_info['token'] = self._get_token(token_info['info'])

    @staticmethod
    def get_user_fields(user_info=None):
        user_info = user_info or {}

        fields = {'name': user_info.get('name') or '',
                  'login': user_info.get('abonent_login') or '',
                  'email': user_info.get('email') or '',
                  'phone': user_info.get('phone') or '',
                  'balance': user_info.get('balance') or '',
                  'current_tariff': user_info.get('current_tariff') or '',
                  'end_date': user_info.get('end_date') or '',
                  'lic_num': user_info.get('lic_num') or '',
                  }

        return fields


class VideoInfo(simplemedia.VideoInfo):

    _data = None
    _path = None
    _for_play = None

    @property
    def path(self):
        return self._path

    def get_poster(self):
        return None

    def get_fanart(self):
        return None

    def get_thumb(self):
        return None

    def set_path(self, path):
        self._path = path

    def _get_list(self, persons):

        items = self._data.get(persons)
        if items is not None:
            return [val for key, val in iteritems(items)]

    @staticmethod
    def _img_url(url):
        if url:
            return 'https://itv.uz{0}'.format(url)

class ChannelInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def playcount(self):
        return 0

    @property
    def plot(self):
        return self._data['description']

    @property
    def title(self):
        return self._data['title']

    @property
    def original_title(self):
        return self._data['title']

    @property
    def mediatype(self):
        return 'video'

    def get_poster(self):
        # icon_url = self._data.get('mobile_icon', '')
        poster_url = self._data.get('poster_url', '')
        # if icon_url:
        #     return self._img_url(icon_url)
        # elif poster_url:
        return self._img_url(poster_url)

    def get_thumb(self):
        return self.get_poster()

class MovieInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def genre(self):
        return self._get_list('genres_obj')

    @property
    def country(self):
        return self._get_list('countries_obj')

    @property
    def year(self):
        return self._data.get('year')

    @property
    def cast(self):
        return self._get_list('actors_obj')

    @property
    def director(self):
        return self._get_list('directors_obj')

    @property
    def plot(self):
        return self._data.get('description')

    @property
    def title(self):
        return self._data['title']

    @property
    def original_title(self):
        return self._data['title_eng']

    @property
    def duration(self):
        return self._data.get('duration')

    @property
    def writer(self):
        return self._get_list('scenarists_obj')

    @property
    def mediatype(self):
        return 'movie'

    def get_poster(self):
        img_url = self._data.get('poster_url', '')
        return self._img_url(img_url)

    def get_fanart(self):
        snapshots = self._data.get('snapshots')
        if snapshots is not None \
            and snapshots:
            return self._img_url(snapshots[0])

class TVShowInfo(MovieInfo):

    def __init__(self, data):

        super(TVShowInfo, self).__init__(data)

        self._for_play = False

    @property
    def tvshowtitle(self):
        self._data['title']

    @property
    def mediatype(self):
        return 'tvshow'


class SeasonInfo(TVShowInfo):

    def __init__(self, tvshow_info, data):

        super(TVShowInfo, self).__init__(tvshow_info)

        self._season_data = data

        self.season_id = data['id']

    @property
    def title(self):
        return self._season_data['name']

    @property
    def episode(self):
        return self._season_data['total_episodes']

    @property
    def season(self):
        return int(self.season_id)

    @property
    def mediatype(self):
        return 'season'

class EpisodeInfo(TVShowInfo):

    def __init__(self, tvshow_info, data):

        super(EpisodeInfo, self).__init__(tvshow_info)

        self._episode_data = data

        self.season_id = data['season_number']
        self.episode_id = data['id']
        self._for_play = True

    @property
    def title(self):
        return self._episode_data['episode_title']

    @property
    def episode(self):
        return int(self._episode_data['episode_number'])

    @property
    def season(self):
        return int(self._episode_data['season_number'])

    @property
    def duration(self):
        return self._data.get('duration')

    @property
    def mediatype(self):
        return 'episode'

    def get_thumb(self):
        img_url = self._episode_data['snapshot']

        return self._img_url(img_url)

class FootballInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def title(self):
        return self._data['title']

    @property
    def original_title(self):
        return self._data['title']

    @property
    def mediatype(self):
        return 'video'

    def get_poster(self):
        img_url = self._data.get('poster_url', '')
        return self._img_url(img_url)

class IslomInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def year(self):
        return self._data.get('year')

    @property
    def plot(self):
        return self._data.get('description')

    @property
    def title(self):
        return self._data['title']

    @property
    def original_title(self):
        return self._data['title_eng']

    @property
    def mediatype(self):
        return 'video'

    def get_poster(self):
        img_url = self._data.get('poster_url', '')
        return self._img_url(img_url)

class PressInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def plot(self):
        return self._data.get('description')

    @property
    def title(self):
        return self._data['title']

    @property
    def original_title(self):
        return self._data['title_eng']

    @property
    def mediatype(self):
        return 'video'

    def get_poster(self):
        img_url = self._data.get('poster_url', '')
        return self._img_url(img_url)

class MusicInfo(VideoInfo):

    def __init__(self, data):
        self._data = data

        self.id = data['id']
        self._for_play = True

    @property
    def year(self):
        return self._data.get('year')

    @property
    def title(self):
        return self._data['title'].split('|')[0]

    @property
    def original_title(self):
        return self._data['title'].split('|')[1]

    @property
    def mediatype(self):
        return 'video'

    def get_poster(self):
        img_url = self._data.get('poster_url', '')
        return self._img_url(img_url)

class EmptyListItem(simplemedia.ListItemInfo):

    plugin = None

    _url = None
    _path = None
    _info = None

    @property
    def path(self):
        return self._path

    @property
    def url(self):
        return self._url

    def set_url(self, url):
        self._url = url

        if isinstance(self._info, simplemedia.VideoInfo):
            self._info.set_path(url)

    def set_path(self, path):
        self._path = path


class ListItem(EmptyListItem):

    def __init__(self, video_info, complete=False):

        self._info = video_info

        self._data = video_info._data
        self._mediatype = video_info.mediatype
        self._for_play = video_info._for_play

    @property
    def label(self):
        return self._info.title

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        return self._mediatype in ['movie', 'episode', 'musicvideo', 'video']


    @property
    def art(self):
        art = {}
        if self._mediatype in ['tvshow', 'movie', 'musicvideo', 'video']:
            art['poster'] = self._info.get_poster()
        elif self._mediatype in ['season', 'episode']:
            art['tvshow.poster'] = self._info.get_poster()

        return art

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season', 'video', 'musicvideo']:
            return self._info.get_poster()
        elif self._mediatype in ['episode']:
            return self._info.get_thumb()

    @property
    def fanart(self):
        fanart = self._info.get_fanart()
        if fanart is not None:
            return fanart
        else:
            return addon.fanart

    @property
    def info(self):
        return {'video': self._info.get_info()}

    @property
    def season(self):
        if self._mediatype in ['season', 'episode']:
            return {'number': self._info.season}
