# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import json

import simplemedia
import xbmc
from future.utils import python_2_unicode_compatible, iteritems, PY26
from resources.libs import iTV, iTVError
from simplemedia import py2_decode, Addon


@python_2_unicode_compatible
class iTVMonitor(xbmc.Monitor):

    def __init__(self):

        super(iTVMonitor, self).__init__()
        addon = Addon()
        addon.log_debug('Started {0}'.format(self))

        self._settings = self._get_settings()
        self._account_info = self._get_account_info()

    def __del__(self):
        Addon().log_debug('Stoped {0}'.format(self))

    def __str__(self):
        return '<iTVMonitor>'

    # def onNotification(self, sender, method, data):
    #     super(iTVMonitor, self).onNotification(sender, method, data)
    #
    #     addon = Addon()
    #     addon.log_debug('{0}.onNotification({1}, {2}, {3})'.format(self, sender, method, py2_decode(data)))
    #
    #     if sender == addon.id:
    #         if method == 'Other.OnPlay':
    #             if data != 'nill':
    #                 data = json.loads(data)
    #                 try:
    #                     ().add_watched(**data)
    #                 except (FilmixError, simplemedia.WebClientError) as e:
    #                     addon.log_error('{0}'.format(e))

    def onSettingsChanged(self):
        super(iTVMonitor, self).onSettingsChanged()

        new_settings = self._get_settings()
        new_account_info = self._get_account_info()

        for key, val in iteritems(new_settings):
            if self._settings[key] != val:
                self.check_user()
                break

        if new_settings['login'] \
            and new_settings['login'] == self._settings['login']:

            for key, val in iteritems(new_account_info):
                if self._account_info[key] != val:
                    iTV().edit_contacts(**new_account_info)
                    break

        self._settings.update(new_settings)
        self._account_info.update(new_account_info)

    @staticmethod
    def _get_settings():
        addon = Addon()

        settings = {'device_id': addon.get_setting('device_id'),
                    'lic_num': addon.get_setting('lic_num'),
                    'login': addon.get_setting('login'),
                    }
        return settings

    @staticmethod
    def _get_account_info():
        addon = Addon()

        account_info = {'email': addon.get_setting('email'),
                        'name': addon.get_setting('name'),
                        'phone': addon.get_setting('phone'),
                        }

        return account_info

    def check_user(self):
        addon = Addon()
        addon.log_debug('{0}.check_user()'.format(self))

        try:
            iTV().check_user()
        except (iTVError, simplemedia.WebClientError) as e:
            return False
        else:
            return True


if __name__ == '__main__':

    sleep_sec = 30
    user_check_sec = 0

    monitor = iTVMonitor()
    while not monitor.abortRequested():

        if user_check_sec <= 0 \
                and monitor.check_user():
            user_check_sec = 1800

        if monitor.waitForAbort(sleep_sec):
            break

        user_check_sec -= sleep_sec
