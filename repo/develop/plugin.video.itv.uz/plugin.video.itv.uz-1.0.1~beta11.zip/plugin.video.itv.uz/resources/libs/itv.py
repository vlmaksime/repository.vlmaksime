# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import base64
import hashlib

from future.utils import PY3, python_2_unicode_compatible

if PY3:
    from urllib.parse import urlencode, urlparse
else:
    from future.backports.urllib.parse import urlencode, urlparse

import requests
import math
import random

__all__ = ['iTVClient', 'iTVError']


class iTVError(Exception):
    pass


@python_2_unicode_compatible
class iTVClient(object):
    __base_url = 'https://itv.uz/api2'

    def __init__(self):

        self.__device_id = ''
        self.__device_type = 'WebSite'
        self.__device_os = ''
        self.__device_brand = ''
        self.__app_version = '2.0'

        self._client = requests.Session()

        headers = {'Content-Type': 'application/x-www-form-urlencoded',
                   'Accept': 'application/json, text/plain, */*',
                   'X-Requested-With': 'XMLHttpRequest',
                   }
        self._client.headers.update(headers)

    def __del__(self):

        self._client.close()

    @staticmethod
    def device_id():
        result = ''
        charsets = '0123456789abcdef'
        while len(result) < 16:
            index = int(math.floor(random.random() * 15))
            result = result + charsets[index]

        md5 = hashlib.md5(result.encode('utf-8'))
        return 'web{0}'.format(md5.hexdigest())

    def set_device_info(self, device_id, device_os, device_brand=''):
        self.__device_id = device_id
        self.__device_os = device_os
        self.__device_brand = device_brand

    @staticmethod
    def __get_url(url, params):
        if params is None:
            return url

        url_parts = urlparse(url)
        url_parts = url_parts._replace(query=urlencode(params))
        return url_parts.geturl()

    def __client_get(self, url, params=None, headers=None, **kwargs):

        url = self.__get_url(url, params)

        headers = headers or {}
        headers['dev-type'] = self.__device_type
        headers['dev-id'] = self.__device_id
        headers['access-key'] = self.__access_key(url)

        return self._client.get(url, headers=headers, **kwargs)

    def __client_post(self, url, params=None, headers=None, **kwargs):

        url = self.__get_url(url, params)

        headers = headers or {}
        headers['dev-type'] = self.__device_type
        headers['dev-id'] = self.__device_id
        headers['access-key'] = self.__access_key(url)

        return self._client.post(url, headers=headers, **kwargs)

    def __access_key(self, url):
        salt = "5xMU-brb2KBqW7r123$)BwhL=,S>VwEEZ7-f#Zykc2E`pGJLACbKgV:vq-)f^:GRUK~D(=,dwVn^RBTW&8Svuyccpb6x9`Y=J#G?xSz,c.wh5V`;~3)&7^Cf_c9y`{%S";

        result = self.__device_id + salt + url[8:]
        md5 = hashlib.md5(result.encode('utf-8'))
        return md5.hexdigest()

    @staticmethod
    def _extract_json(r):
        try:
            j = r.json()
        except ValueError as e:
            raise iTVError(e)

        if isinstance(j, dict):
            status = j.get('status')
            if status == 'error':
                message =  j.get('message', 'Undefined error')
                raise iTVError(message)

        return j

    def login(self, _login, _password):
        url = self.__base_url + '/authentication/login'

        auth = '{0}:{1}'.format(_login, _password)
        login_data = base64.b64encode(auth.encode('utf-8'))
        data = {'login-data': login_data,
                'dev-model': self.__device_os,
                'dev-type': self.__device_type,
                'dev-brand': self.__device_brand,
                'app-version': self.__app_version,
                }

        r = self.__client_post(url, data=data)
        j = self._extract_json(r)

        return j

    def logout(self):
        url = self.__base_url + '/authentication/logout'

        r = self.__client_post(url)
        j = self._extract_json(r)

        return j

    def edit_contacts(self, name, email, phone):
        url = self.__base_url + '/authentication/edit_contacts'

        data = {'name': name,
                'email': email,
                'phone': phone,
                }

        r = self.__client_post(url, data=data)
        j = self._extract_json(r)

        return j

    def user_info(self):
        url = self.__base_url + '/authentication/balance'

        r = self.__client_post(url)
        j = self._extract_json(r)

        return j

    def channels_list(self, **kwargs):
        url = self.__base_url + '/channels/list'

        r = self.__client_post(url)
        j = self._extract_json(r)

        result = {'offset': 0,
                  'total_items': j['total_items'],
                  'items_per_page': j['items_per_page'],
                  'list': j['data']['channels'],
                  }
        return result

    def channel_info(self, channel_id):
        url = self.__base_url + '/channels/showchannel'

        params = {'id': channel_id,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        return j['data']['channel']


    def movies_list(self, **kwargs):
        url = self.__base_url + '/movies/movieslist'

        params = {'tvshow': kwargs.get('tvshow', 0),
                  'genre': kwargs.get('genre', 'undefined'),
                  'country': kwargs.get('country', 'undefined'),
                  'cat_id': kwargs.get('cat_id', 'undefined'),
                  'page': kwargs.get('page', 1),
                  'cartoon': kwargs.get('cartoon', 0),
                  'uzb': kwargs.get('uzb', 0),
                  'year': kwargs.get('year', 'undefined'),
                  'items': kwargs.get('items', 'undefined'),
                  'hd': kwargs.get('hd', 'undefined'),
                  'is3d': kwargs.get('is3d', 'undefined'),
                  'is4k': kwargs.get('is4k', 'undefined'),
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)
        # j = self._tvshow_list()

        if j.get('data') is not None:
            list = j['data']['movies']
        else:
            list = []
        result = {'offset': 0,
                  'total_items': j['total_items'],
                  'items_per_page': j['items_per_page'],
                  'list': list,
                  }
        return result

    def seasons_list(self, tvshow_id):
        url = self.__base_url + '/movies/seasonslist'

        params = {'id': tvshow_id,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)
        # j = self._season_list()

        result = {'offset': 0,
                  'total_items': len(j['data']['seasons']),
                  'items_per_page': len(j['data']['seasons']),
                  'list': j['data']['seasons'],
                  }
        return result

    def episodes_list(self, tvshow_id, season_id):
        url = self.__base_url + '/movies/tvshowlist'

        params = {'id': tvshow_id,
                  'season': season_id,
                  'full': 1,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)
        # j = self._episodes_list()

        result = {'offset': 0,
                  'total_items': j['total_items'],
                  'items_per_page': j['items_per_page'],
                  'list': j['data']['episodes'],
                  }
        return result


    def search_list(self, word, **kwargs):
        url = self.__base_url + '/movies/search'

        params = {'word': word,
                  'page': kwargs.get('page', 'undefined'),
                  'items': kwargs.get('items', 'undefined'),
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        result = {'offset': 0,
                  'total_items': j['total_items'],
                  'items_per_page': j['items_per_page'],
                  'list': j['data']['movies'],
                  }
        return result

    def movie_info(self, movie_id):
        url = self.__base_url + '/movies/show'

        params = {'id': movie_id,
                  'st': 1,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)
        # j = self._tvshow_info()

        return j['data']['movie']

    def football_list(self, **kwargs):
        url = self.__base_url + '/football/list'

        params = {'genre': 0,
                  'page': kwargs.get('page', 'undefined'),
                  'items': kwargs.get('items', 'undefined'),
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        result = {'offset': 0,
                  'total_items': int(j['data']['total_items']),
                  'items_per_page': int(j['data']['items_per_page']),
                  'list': j['data']['movies'],
                  }
        return result


    def islom_list(self, **kwargs):
        url = self.__base_url + '/islom/get_clips'

        params = {'category': 0,
                  'page': kwargs.get('page', 'undefined'),
                  'items': kwargs.get('items', 'undefined'),
                  'ver': 1,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        result = {'offset': j['offset'],
                  'total_items': j['total_items'],
                  'items_per_page': int(j['items_per_page']),
                  'list': j['data']['islom_list'],
                  }
        return result

    def islom_info(self, islom_id):
        url = self.__base_url + '/islom/show_clip'

        params = {'id': islom_id,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        return j['data']['islom']

    def press_list(self, **kwargs):
        url = self.__base_url + '/press/get_clips'

        params = {'page': kwargs.get('page', 'undefined'),
                  'items': kwargs.get('items', 'undefined'),
                  'ver': 1,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        result = {'offset': j['offset'],
                  'total_items': j['total_items'],
                  'items_per_page': int(j['items_per_page']),
                  'list': j['data']['press_list'],
                  }
        return result

    def press_info(self, press_id):
        url = self.__base_url + '/press/show_clip'

        params = {'id': press_id,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        return j['data']['press']


    def music_list(self, **kwargs):
        url = self.__base_url + '/music/get_clips'

        params = {'page': kwargs.get('page', 'undefined'),
                  'cat': 0,
                  'items': kwargs.get('items', 'undefined'),
                  'is_concert': kwargs.get('is_concert', 0),
                  'search': '',
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        result = {'offset': j['offset'],
                  'total_items': j['total_items'],
                  'items_per_page': int(j['items_per_page']),
                  'list': j['data']['clips'],
                  }
        return result

    def music_info(self, music_id):
        url = self.__base_url + '/music/show_clip'

        params = {'id': music_id,
                  }

        r = self.__client_post(url, params=params)
        j = self._extract_json(r)

        return j['data']['clip']


    # @staticmethod
    # def _tvshow_list():
    #     import json
    #     text = '{"code":200,"total_items":6791,"items_per_page":24,"status":"success","data":{"movies":[{"id":26696,"poster_url":"/uploads/images/2020/06/prtl859cfd8d4fd15c665d79f7b95b21520a-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Главные роли","isnew":1,"year":2002,"genres_obj":{"9":"драма","15":"мелодрама"},"countries_obj":{"43":"Россия"},"is_free":"false","subscription_status":"pay"},{"id":26694,"poster_url":"/uploads/images/2020/06/prtl016385a67a4e6aed1b3215ee51db540b-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"В густом лесу","isnew":1,"year":2020,"genres_obj":{"6":"Детектив","30":"триллер","9":"драма"},"countries_obj":{"47":"США","41":"Польша"},"is_free":"false","subscription_status":"pay"},{"id":26019,"poster_url":"/uploads/images/2020/05/prtla6412d63b0aa7de633715752b3778cfe-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Жена-левша","isnew":1,"year":2019,"genres_obj":{"15":"мелодрама","6":"детектив"},"countries_obj":{"27":"Корея Южная"},"is_free":"false","subscription_status":"pay"},{"id":26208,"poster_url":"/uploads/images/2020/05/prtlf7afb42b840c3ea20b8c49a0bd7c250b-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Девять километров любви","isnew":1,"year":2019,"genres_obj":{"15":"мелодрама"},"countries_obj":{"25":"Китай"},"is_free":"false","subscription_status":"pay"},{"id":26142,"poster_url":"/uploads/images/2020/05/prtlba52198cdfe5ca539c98109cdaf2ac0d-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Любовь от кутюр","isnew":1,"year":2020,"genres_obj":{"15":"мелодрама"},"countries_obj":{"25":"Китай"},"is_free":"false","subscription_status":"pay"},{"id":25601,"poster_url":"/uploads/images/2020/04/prtl8fe5c333ef25e896826c3c5b1752b701-q-50350x501.jpg","hd":"1080p","is3d":0,"is4k":0,"cartoon":0,"title":"Восьмой сын? Такого я принять не могу!","isnew":1,"year":2020,"genres_obj":{"1":"Аниме"},"countries_obj":{"60":"Япония"},"is_free":"false","subscription_status":"pay"},{"id":26331,"poster_url":"/uploads/images/2020/05/prtl108c45ab03caa900d504dbbcec8eb6e1-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Центральный парк","isnew":1,"year":2020,"genres_obj":{"18":"мюзикл","12":"комедия"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"},{"id":26666,"poster_url":"/uploads/images/2020/06/prtl5cddd863f204c5d4b1f613699c287beb-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Постановка","isnew":1,"year":2020,"genres_obj":{"12":"комедия"},"countries_obj":{"10":"Великобритания"},"is_free":"false","subscription_status":"pay"},{"id":23649,"poster_url":"/uploads/images/2019/11/prtl360e0c70f88486b15398b44bd0709902-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Харли Квинн","isnew":1,"year":2019,"genres_obj":{"32":"фантастика","33":"фэнтези","3":"боевик","12":"комедия","14":"криминал","6":"детектив","21":"приключения"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"},{"id":26388,"poster_url":"/uploads/images/2020/06/prtlaa28b83ec98194eaf96f6eb4634cd426-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Чёрная лестница","isnew":1,"year":2020,"genres_obj":{"30":"триллер","9":"драма"},"countries_obj":{},"is_free":"false","subscription_status":"pay"},{"id":23404,"poster_url":"/uploads/images/2019/11/prtl376c2b6f4228e2291467f725a0677207-q-50350x501.jpg","hd":"720p","is3d":0,"is4k":0,"cartoon":0,"title":"Это моя жизнь","isnew":1,"year":2018,"genres_obj":{"15":"мелодрама"},"countries_obj":{"27":"Корея Южная"},"is_free":"false","subscription_status":"pay"},{"id":26329,"poster_url":"/uploads/images/2020/05/prtl16b5b629783a3815e5ca041786eb0df1-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Чума!","isnew":1,"year":2020,"genres_obj":{"12":"Комедия"},"countries_obj":{},"is_free":"false","subscription_status":"pay"},{"id":8841,"poster_url":"/uploads/images/2015/06/27/558e462fc0e2a6.75343256-q-50350x501.gif","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Главная дорога","isnew":1,"year":2005,"genres_obj":{"8":"Документальный","28":"Телепередача","53":"Познавательный"},"countries_obj":{"43":"Россия"},"is_free":"false","subscription_status":"pay"},{"id":12554,"poster_url":"/uploads/images/2016/12/10/584bc920794bf5.36252616-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Квартирный вопрос","isnew":1,"year":2014,"genres_obj":{"8":"Документальный"},"countries_obj":{"43":"Россия"},"is_free":"false","subscription_status":"pay"},{"id":6617,"poster_url":"/uploads/images/2014/03/23/532df63d71cc01.83773307-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Сотня","isnew":1,"year":2013,"genres_obj":{"32":"Фантастика"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"},{"id":7530,"poster_url":"/uploads/images/2019/07/prtl5664a829793b4f3894c910bafc56eb47-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Агенты «Щ.И.Т.»","isnew":1,"year":2013,"genres_obj":{"3":"Боевик","9":"Драма","32":"Фантастика"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"},{"id":26676,"poster_url":"/uploads/images/2020/06/prtl9bdf21c54384b3f0c1cd9db905577ee8-q-50350x501.jpg","hd":"1080p","is3d":0,"is4k":0,"cartoon":0,"title":"Древние небеса","isnew":1,"year":2019,"genres_obj":{"8":"документальный","11":"история"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"},{"id":21895,"poster_url":"/uploads/images/2019/07/prtlc05c20be0f4c73d7eb0058e00e62b5c7-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Королева кондитерской","isnew":1,"year":2019,"genres_obj":{"9":"драма","15":"мелодрама","12":"комедия"},"countries_obj":{"9":"Бразилия"},"is_free":"false","subscription_status":"pay"},{"id":26643,"poster_url":"/uploads/images/2020/06/prtl1f7b5d97e0648b795425460e6de51392-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Королева Марго","isnew":1,"year":1997,"genres_obj":{"9":"драма","15":"мелодрама"},"countries_obj":{"43":"Россия"},"is_free":"false","subscription_status":"pay"},{"id":24723,"poster_url":"/uploads/images/2020/02/prtl05e6d51663dc626cfc82f1cdd529a76d-q-50350x501.jpg","hd":"1080p","is3d":0,"is4k":0,"cartoon":0,"title":"Джи Ву Ген: Непокорный воле богов","isnew":1,"year":2016,"genres_obj":{"21":"Приключения","33":"Фэнтези","1":"Аниме"},"countries_obj":{"25":"Китай"},"is_free":"false","subscription_status":"pay"},{"id":26677,"poster_url":"/uploads/images/2020/06/prtl6602286d8feb4bdb3425abf5f10ccda3-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Сатисфакция","isnew":1,"year":2005,"genres_obj":{"21":"Приключения"},"countries_obj":{"43":"Россия"},"is_free":"false","subscription_status":"pay"},{"id":21216,"poster_url":"/uploads/images/2019/05/prtlc02704652322ca857b61d8118fd0a172-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Кандис Ренуар ","isnew":1,"year":2013,"genres_obj":{"9":"драма","12":"комедия","14":"криминал"},"countries_obj":{"54":"Франция"},"is_free":"false","subscription_status":"pay"},{"id":24135,"poster_url":"/uploads/images/2020/01/prtl69eb02783fd1d4c227d67d6e4390bd1e-q-50350x501.jpg","hd":"1080p","is3d":0,"is4k":0,"cartoon":0,"title":"Грабитель","isnew":1,"year":2020,"genres_obj":{"1":"аниме","3":"боевик","33":"фэнтези"},"countries_obj":{"60":"Япония"},"is_free":"false","subscription_status":"pay"},{"id":21153,"poster_url":"/uploads/images/2019/05/prtl23f4b1f2bb879b70827c67f52d0e4aa6-q-50350x501.jpg","hd":null,"is3d":0,"is4k":0,"cartoon":0,"title":"Лучшие в Лос-Анджелесе ","isnew":0,"year":2019,"genres_obj":{"3":"боевик","12":"комедия","14":"криминал"},"countries_obj":{"47":"США"},"is_free":"false","subscription_status":"pay"}]}}'
    #
    #     return json.loads(text)
    #
    # @staticmethod
    # def _season_list():
    #     import json
    #     text = '{"code":200,"status":"success","data":{"seasons":[{"id":"1","name":"Сезон 1","total_episodes":"18"}]}}'
    #
    #     return json.loads(text)
    #
    #
    # @staticmethod
    # def _tvshow_info():
    #     import json
    #     text = '{"code":200,"subscription_status":"active","status":"success","data":{"movie":{"id":26643,"file_id":276989,"duration":0,"last_time":0,"poster_url":"/uploads/images/2020/06/prtl1f7b5d97e0648b795425460e6de51392-q-50350x500.jpg","video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo01ser..mp4/index.m3u8?s=1M23mCjPcrtkXh4bEdiLLg&e=1592228249","secure_video_url":"","episode_id":276989,"episode_title":"Сезон 1 :: Эпизод 1","season_number":"1","episode_number":"1","episode_name":"Книга судеб","title":"Королева Марго","snapshots":["/uploads/images/2020/06/prtl86a42cd63bc5eb3f96223cc4a40b0f25.jpg","/uploads/images/2020/06/prtl237ab7788b49e1f990c112221bb351f2.jpg","/uploads/images/2020/06/prtldd481cfb7a69122bbeae5e7eac7346ad.jpg","/uploads/images/2020/06/prtl67c74a079fb2ef05caa21e1c32fcfb35.jpg"],"title_eng":"","description":"История заката правления французской династии Валуа, полная драматизма, религиозных противоречий, дворцовых и любовных интриг","budget":"","slogan":"","year":1997,"countries_obj":{"43":"Россия"},"genres_obj":{"9":"драма","15":"мелодрама"},"directors_obj":{"1065":"Александр Муратов"},"scenarists_obj":{},"producers_obj":{},"actors_obj":{"6878":"Евгения Добровольская","6090":"Дмитрий Певцов","11080":"Михаил Ефремов","24162":"Екатерина Васильева","6103":"Дмитрий Харатьян","19970":"Сергей Жигунов","61872":"Вера Сотникова","32510":"Сергей Юрский","11068":"Михаил Боярский","11816":"Николай Караченцов"},"hd":null,"is3d":0,"is4k":0,"is_tvshow":1,"rating_imdb":"0","rating_kinopoisk":"0","age_kp":0,"mpaa_img":null,"is_free":"false","is_uzb":false}}}'
    #
    #     return json.loads(text)
    #
    # @staticmethod
    # def _episodes_list():
    #     import json
    #     text = '{"total_items":18,"items_per_page":18,"code":200,"subscription_status":"active","status":"success","data":{"episodes":[{"id":276989,"file_id":276989,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo01ser..mp4/index.m3u8?s=jrWEY_HkxceHUPum_hlsUw&e=1592228264","title":"Cезон 1 :: Эпизод 1","season_number":"1","episode_number":"1","episode_title":"Книга судеб","snapshot":"/uploads/images/2020/06/prtlc92fa432c80fb74e25e24a8bb512ee54-q-100200x100.jpg","duration":3146,"last_time":0},{"id":276990,"file_id":276990,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo02ser..mp4/index.m3u8?s=c4bnyuA0zqdeYMe4AjBvrQ&e=1592228264","title":"Cезон 1 :: Эпизод 2","season_number":"1","episode_number":"2","episode_title":"День Святого Варфоломея","snapshot":"/uploads/images/2020/06/prtl744a9b70bfd5ea7f959a3149adf5389b-q-100200x100.jpg","duration":3033,"last_time":0},{"id":276991,"file_id":276991,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo03ser..mp4/index.m3u8?s=EhkZP5pcBQ36YJvjwqDbcA&e=1592228264","title":"Cезон 1 :: Эпизод 3","season_number":"1","episode_number":"3","episode_title":"Кровавая месса","snapshot":"/uploads/images/2020/06/prtlf9e2f5db0aa434d8676bd1260d503efd-q-100200x100.jpg","duration":3119,"last_time":0},{"id":276992,"file_id":276992,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo04ser..mp4/index.m3u8?s=Pblq3PcvKdUkeLT9qTA1ww&e=1592228264","title":"Cезон 1 :: Эпизод 4","season_number":"1","episode_number":"4","episode_title":"Горе побежденным","snapshot":"/uploads/images/2020/06/prtlc15f7d88c3961ae88d157bb52109a778-q-100200x100.jpg","duration":3112,"last_time":0},{"id":276993,"file_id":276993,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo05ser..mp4/index.m3u8?s=fngCXlqTdi8ttYhR6oxnkA&e=1592228264","title":"Cезон 1 :: Эпизод 5","season_number":"1","episode_number":"5","episode_title":"Любовь небесная, Любовь земная","snapshot":"/uploads/images/2020/06/prtl5062b22473e3d3819ee49b174f4ed8d0-q-100200x100.jpg","duration":3103,"last_time":0},{"id":276994,"file_id":276994,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo06ser..mp4/index.m3u8?s=o8CynhXEEPz864CcJjNllw&e=1592228264","title":"Cезон 1 :: Эпизод 6","season_number":"1","episode_number":"6","episode_title":"Поединок","snapshot":"/uploads/images/2020/06/prtl590fbb8dde1da4498bc461a6c91ba517-q-100200x100.jpg","duration":3092,"last_time":0},{"id":276995,"file_id":276995,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo07ser..mp4/index.m3u8?s=WEYjGdarMx3ReDeLZ2XIEQ&e=1592228264","title":"Cезон 1 :: Эпизод 7","season_number":"1","episode_number":"7","episode_title":"Рукопожатие палача","snapshot":"/uploads/images/2020/06/prtle132aa0221c3050bc11123501ca0e911-q-100200x100.jpg","duration":3179,"last_time":0},{"id":276996,"file_id":276996,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo08ser..mp4/index.m3u8?s=AFOi3sRtqbyTs41TyIfugA&e=1592228264","title":"Cезон 1 :: Эпизод 8","season_number":"1","episode_number":"8","episode_title":"Плащ из вишневого бархата","snapshot":"/uploads/images/2020/06/prtl6d50fa466ff0a4e99e00d7db4ce2d9e0-q-100200x100.jpg","duration":3115,"last_time":0},{"id":276997,"file_id":276997,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo09ser..mp4/index.m3u8?s=JFUvRMA8RgQvfrNazP8BkA&e=1592228264","title":"Cезон 1 :: Эпизод 9","season_number":"1","episode_number":"9","episode_title":"Королевские гончие","snapshot":"/uploads/images/2020/06/prtl2444a3ea56c78a655933833d8a65a2f3-q-100200x100.jpg","duration":3124,"last_time":0},{"id":276998,"file_id":276998,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo10ser..mp4/index.m3u8?s=cBEg8M_GnRjBgUQpdWFkTQ&e=1592228264","title":"Cезон 1 :: Эпизод 10","season_number":"1","episode_number":"10","episode_title":"Некоролевское счастье","snapshot":"/uploads/images/2020/06/prtl8dc2c53519598b2025601d722ddc6185-q-100200x100.jpg","duration":3117,"last_time":0},{"id":276999,"file_id":276999,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo11ser..mp4/index.m3u8?s=X56zgGm_fNDAsaUF7SuSEQ&e=1592228264","title":"Cезон 1 :: Эпизод 11","season_number":"1","episode_number":"11","episode_title":"Сыновья волчицы","snapshot":"/uploads/images/2020/06/prtl456d66314736672d3360455489292596-q-100200x100.jpg","duration":3120,"last_time":0},{"id":277000,"file_id":277000,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo12ser..mp4/index.m3u8?s=LhRcZt5h2-opE21w0YR6ZA&e=1592228264","title":"Cезон 1 :: Эпизод 12","season_number":"1","episode_number":"12","episode_title":"Веревочная лестница","snapshot":"/uploads/images/2020/06/prtl5514579a2e0c34a847ed11d5d2b4e1fe-q-100200x100.jpg","duration":3107,"last_time":0},{"id":277001,"file_id":277001,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo13ser..mp4/index.m3u8?s=g5gMFR9AEU6L-oKcLpV0ow&e=1592228264","title":"Cезон 1 :: Эпизод 13","season_number":"1","episode_number":"13","episode_title":"Счастливчик Ла Моль","snapshot":"/uploads/images/2020/06/prtl8cbcd86a4011def53157e3c763c1aaad-q-100200x100.jpg","duration":3120,"last_time":0},{"id":277002,"file_id":277002,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo14ser..mp4/index.m3u8?s=RBEru6FxRwsRiAsM-xd00w&e=1592228264","title":"Cезон 1 :: Эпизод 14","season_number":"1","episode_number":"14","episode_title":"Пятница, тринадцатое","snapshot":"/uploads/images/2020/06/prtl9db2f83d47cecca9fd21b5101440f4c2-q-100200x100.jpg","duration":3122,"last_time":0},{"id":277003,"file_id":277003,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo15ser..mp4/index.m3u8?s=X7TsLMYQhTcGw89uWNkA3w&e=1592228264","title":"Cезон 1 :: Эпизод 15","season_number":"1","episode_number":"15","episode_title":"Честь дома Валуа","snapshot":"/uploads/images/2020/06/prtlde0d98ea6294b437fef86037bf532bb1-q-100200x100.jpg","duration":3116,"last_time":0},{"id":277004,"file_id":277004,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo16ser..mp4/index.m3u8?s=i8I5YkQRYVOCL7cOOsgt6Q&e=1592228264","title":"Cезон 1 :: Эпизод 16","season_number":"1","episode_number":"16","episode_title":"Венсенский замок","snapshot":"/uploads/images/2020/06/prtl3effba3265e03e636d823c0890fa613c-q-100200x100.jpg","duration":3112,"last_time":0},{"id":277005,"file_id":277005,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo17ser..mp4/index.m3u8?s=qihHPcOxQTxJfC9yacBHdg&e=1592228264","title":"Cезон 1 :: Эпизод 17","season_number":"1","episode_number":"17","episode_title":"Испанские сапоги","snapshot":"/uploads/images/2020/06/prtl31fc0adada029b19dfd9a914dad49a9c-q-100200x100.jpg","duration":3118,"last_time":0},{"id":277006,"file_id":277006,"video_url":"https://storage10.itv.uz/hls/converted%2FVideo%2Fserials%2FKorolevaMargo%2Fs1/KorolevaMargo18ser..mp4/index.m3u8?s=l3kEck6s_vQYUuQweOiaPQ&e=1592228264","title":"Cезон 1 :: Эпизод 18","season_number":"1","episode_number":"18","episode_title":"Пепел","snapshot":"/uploads/images/2020/06/prtl56ffecc8a6f5e477d697aa3674745a85-q-100200x100.jpg","duration":2982,"last_time":0}]}}'
    #
    #     return json.loads(text)
