# -*- coding: utf-8 -*-
"""IPTV Manager Integration module"""

import json
import socket


class IPTVManager:
    """Interface to IPTV Manager"""

    def __init__(self, port):
        """Initialize IPTV Manager object"""
        self.port = port

    def via_socket(func):
        """Send the output of the wrapped function to socket"""

        def send(self, data):
            """Decorator to send over a socket"""
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(('127.0.0.1', self.port))
            try:
                sock.sendall(json.dumps(func(self, data)))
            finally:
                sock.close()

        return send

    @via_socket
    def send_channels(self, items):
        """Return JSON-STREAMS formatted information to IPTV Manager"""
        channels = []
        for entry in items:
            channels.append(dict(
                id=entry.get('id'),
                name=entry.get('label'),
                logo=entry.get('logo'),
                stream=entry.get('url'),
            ))
        return dict(version=1, streams=channels)

    @via_socket
    def send_epg(self):
        """Return JSON-EPG formatted information to IPTV Manager"""
        from resources.lib.tvguide import TVGuide
        epg_data = TVGuide().get_epg_data()
        return dict(version=1, epg=epg_data)