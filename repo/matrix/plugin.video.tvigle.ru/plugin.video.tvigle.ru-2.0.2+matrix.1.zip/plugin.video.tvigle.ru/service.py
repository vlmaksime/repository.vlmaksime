# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import python_2_unicode_compatible, iteritems
from resources import Tvigle, TvigleError
from simplemedia import Addon, py2_decode

import xbmc
import json
import simplemedia


@python_2_unicode_compatible
class TvigleMonitor(xbmc.Monitor):

    _progress_interval = 30
    _last_position = 0
    _current_position = 0
    _item = None

    def __init__(self):

        super(TvigleMonitor, self).__init__()

        addon = Addon()
        addon.log_debug('Started {0}'.format(self))

        self._settings = self._get_settings()
        self._pk = addon.get_setting('pk')
        self._player = xbmc.Player()

    def __del__(self):
        Addon().log_debug('Stoped {0}'.format(self))

    def __str__(self):
        return '<TvigleMonitor>'

    def onNotification(self, sender, method, data):

        super(TvigleMonitor, self).onNotification(sender, method, data)

        addon = Addon()
        addon.log_debug('{0}.onNotification({1}, {2}, {3})'.format(self, sender, method, py2_decode(data)))

        if data != 'nill':
            data = json.loads(data)

        if sender == 'xbmc':
            if method in ['Player.OnPlay', 'Player.OnPause', 'Player.OnSeek']:
                self._update_position()
                self.update_progress()
            elif method in ['Player.OnStop']:
                if self._item is not None:
                    if data.get('end', False) \
                      and (self._current_position + self._progress_interval) >= self._item['duration']:
                        self._current_position = self._item['duration']
                    self.update_progress()

                    self._item = None

        elif sender == addon.id:
            if method == 'Other.OnPlay':
                if self._item is not None \
                  and self._item['video_id'] != data['video_id']:
                    self._update_position()
                    self.update_progress()

                self._item = data
                self._last_position = 0
                self._current_position = 0

    def onSettingsChanged(self):

        super(TvigleMonitor, self).onSettingsChanged()

        new_settings = self._get_settings()

        self._pk = Addon().get_setting('pk')
        if self._pk \
          and new_settings != self._settings:

            differences = {}
            for key, val in iteritems(new_settings):
                if self._settings[key] != val:
                    differences[key] = val

            if differences:
                Tvigle().update_account(differences)

        self._settings.update(new_settings)

    @staticmethod
    def _get_settings():
        addon = Addon()

        gender = addon.get_setting('customer_gender')

        settings = {'username': addon.get_setting('username'),
                    'birth_date': addon.get_setting('birth_date'),
                    'gender': 'male' if gender == 0 else 'female',
                    'is_subscribe': addon.get_setting('is_subscribe'),
                    }
        return settings

    def _update_position(self):

        if self._player.isPlaying():
            self._current_position = self._player.getTime()

    def sync_progress(self):

        if self._item is not None:
            self._update_position()

            if (self._current_position - self._last_position) >= self._progress_interval:
                self.update_progress()

    def update_progress(self):
        if self._pk \
          and self._item is not None:
            if self._current_position != self._last_position:
                try:
                    Tvigle().video_user_hr(self._item['video_id'], self._current_position)
                except (TvigleError, simplemedia.WebClientError) as e:
                    addon.notify_error(e)
                else:
                    self._last_position = self._current_position


if __name__ == '__main__':

    default_dev_check_sec = 1800
    sleep_sec = 10
    dev_check_sec = 0

    monitor = TvigleMonitor()
    while not monitor.abortRequested():

        if dev_check_sec <= 0:
            try:
                Tvigle().check_account()
            except (TvigleError, simplemedia.WebClientError) as e:
                pass
            else:
                dev_check_sec = default_dev_check_sec

        if monitor.waitForAbort(sleep_sec):
            break

        monitor.sync_progress()
        dev_check_sec -= sleep_sec
