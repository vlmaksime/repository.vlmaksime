# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
import xbmc
import xbmcplugin

from resources import Tvigle, TvigleError, ProductInfo, SeasonInfo, VideoInfo, EmptyListItem, ListItem

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

ProductInfo.plugin = plugin
EmptyListItem.plugin = plugin


@plugin.route('/login')
def login():
    email = plugin.get_keyboard_text('', _('Enter your e-mail'))
    if email:

        xbmc.sleep(1000)

        password = plugin.get_keyboard_text('', _('Enter your password'), True)
        if password:
            try:
                api = Tvigle()
                login_result = api.login(email, password)
            except (TvigleError, simplemedia.WebClientError) as e:
                plugin.notify_error(e, True)
            else:
                del email
                del password

                if login_result['status'] == 'ok':
                    login_data = login_result['data']
                    api.update_token(login_data['token'])
                    user_fields = api.get_user_fields(login_data['account'])
                    plugin.set_settings(user_fields)

                    plugin.dialog_ok(_('You have successfully logged in'))


@plugin.route('/logout')
def logout():
    api = Tvigle()
    api.logout()
    user_fields = api.get_user_fields()
    plugin.set_settings(user_fields)

    plugin.dialog_ok(_('You have successfully logged out'))


@plugin.route('/')
def root():
    plugin.create_directory(_root_list(), content='', category=plugin.name)


def _root_list():
    for item in _category_items():
        url = plugin.url_for('category', cat_slug=item['slug'])
        list_item = {'label': item['name'],
                     'url': url,
                     'icon': item['icon'],
                     'fanart': item['image'],
                     'info': {'video': {'plot': item['description'],
                                        },
                              },
                     'is_folder': True,
                     'is_playble': False,
                     'content_lookup': False,
                     }
        yield list_item

    url = plugin.url_for('search_history')
    list_item = {'label': _('Search'),
                 'url': url,
                 'icon': plugin.get_image('DefaultAddonsSearch.png'),
                 'fanart': plugin.fanart,
                 'is_folder': True,
                 'is_playble': False,
                 'content_lookup': False,
                 }
    yield list_item


@plugin.route('/category/<cat_slug>/')
def category(cat_slug):
    cat_info = _category_info(cat_slug)
    if cat_info is None:
        plugin.create_directory([], succeeded=False)
        return

    offset = plugin.params.offset or '0'
    offset = int(offset)

    limit = plugin.params.limit
    if not limit:
        limit = plugin.get_setting('limit', False)
    limit = int(limit)
    try:
        if cat_info['account_method']:
            category_result = Tvigle().account_category(cat_info['id'], offset, limit)
        else:
            category_result = Tvigle().category_product(cat_info['id'], offset, limit)
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:
        page_params = {'cat_slug': cat_slug,
                       }

        pages = _get_pages(page_params, offset, limit, category_result['count'], 'category')

        category_parts = [cat_info['name'],
                          '{0} {1}'.format(_('Page'), int(offset / limit) + 1),
                          ]
        if cat_info['id'] == 'history':
            items = _list_history(category_result['results'], pages)
        else:
            items = _list_category(category_result['results'], pages)

        result = {'items': items,
                  'total_items': len(category_result['results']),
                  'content': cat_info['content'],
                  'category': ' / '.join(category_parts),
                  'sort_methods': cat_info['sort_method'],
                  'update_listing': (offset > 0),
                  }
        plugin.create_directory(**result)


def _list_category(items, pages=None):
    use_atl_names = _use_atl_names()

    api = Tvigle()

    for item in items:

        video_info = ProductInfo(item, atl_names=use_atl_names)
        if video_info.mediatype in ['movie', 'musicvideo', 'video']:
            video_item = api.video(video_info.video_id)
            video_info = VideoInfo(item, video_item, atl_names=use_atl_names)

        listitem = ListItem(video_info)

        url = _get_listitem_url(video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()

    if pages is not None:
        for listitem in _page_items(pages):
            yield listitem


def _list_history(items, pages=None):
    use_atl_names = _use_atl_names()

    api = Tvigle()

    for item in items:
        video_item = item['video']
        product_item = api.product(video_item['product_id'])

        video_info = VideoInfo(product_item, video_item, atl_names=use_atl_names, for_history=True)

        listitem = ListItem(video_info, complete=item['complete'])

        url = _get_listitem_url(video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()

    if pages is not None:
        for listitem in _page_items(pages):
            yield listitem


@plugin.route('/product/<product_id>/')
def seasons(product_id):
    try:
        api = Tvigle()
        product_item = api.product(product_id)
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        plugin.create_directory([], succeeded=False)
    else:

        group_items = _get_group_items(product_item)

        result = {'items': _list_seasons(product_item, group_items),
                  'total_items': len(group_items),
                  'content': 'seasons',
                  'category': product_item['name'],
                  'sort_methods': xbmcplugin.SORT_METHOD_UNSORTED,
                  }
        plugin.create_directory(**result)


def _list_seasons(product_item, season_items):
    use_atl_names = _use_atl_names()

    for season_item in season_items:
        video_info = SeasonInfo(product_item, season_item)
        listitem = ListItem(video_info)

        url = _get_listitem_url(video_info, use_atl_names)
        listitem.set_url(url)

        yield listitem.get_item()


@plugin.route('/product/<product_id>/episodes/', 'episodes_empty_group')
@plugin.route('/product/<product_id>/epidoses/', 'episodes_empty_group_typo')
@plugin.route('/product/<product_id>/<int:group_id>/episodes/')
def episodes(product_id, group_id=None):
    try:
        api = Tvigle()
        product_item = api.product(product_id)
        group_info = _get_group_info(product_item, group_id)

        limit = product_item['videos_count']

        video_result = api.product_video(product_id, group_id, limit=limit)
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        plugin.create_directory([], succeeded=False)
    else:

        if group_id is None:
            video_items = video_result['results']
        else:
            video_items = []
            for item in video_result['results']:
                if item['group_id'] == group_id:
                    video_items.append(item)

        if _use_atl_names():
            sort_method = xbmcplugin.SORT_METHOD_UNSORTED
        else:
            sort_method = xbmcplugin.SORT_METHOD_EPISODE

        result = {'items': _list_episodes(product_item, video_items),
                  'total_items': len(video_items),
                  'content': 'episodes',
                  'category': ' / '.join([product_item['name'], group_info['name']]),
                  'sort_methods': sort_method,
                  }
        plugin.create_directory(**result)


def _list_episodes(product_item, video_items):
    use_atl_names = _use_atl_names()

    ext_item_params = {}
    if use_atl_names:
        ext_item_params['atl'] = 1

    for video_item in video_items:
        video_info = VideoInfo(product_item, video_item, atl_names=use_atl_names)

        listitem = ListItem(video_info)
        url = plugin.url_for('play_video', video_id=video_item['id'], **ext_item_params)

        listitem.set_url(url)

        yield listitem.get_item()


@plugin.route('/video/<video_id>/')
def play_video(video_id):
    try:
        api = Tvigle()
        video_result = api.video(video_id)
        product_result = api.product(video_result['product_id'])
        links_result = api.video_links(video_result['content_id'])
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        plugin.resolve_url({}, False)
        return
    else:
        is_strm = plugin.params.strm == '1' \
                  and plugin.kodi_major_version() >= '18'

        succeeded = True

        video_info = VideoInfo(product_result, video_result, True)

        if video_info.is_paid:
            plugin.notify_error(_('Video should be purchased'), True)
            plugin.resolve_url({}, False)
            return

        data = {'video_id': video_info.video_id,
                'duration': video_info.duration,
                'title': video_info.title,
                }

        listitem = ListItem(video_info)

        url = plugin.url_for('play_video', video_id=listitem.video_id)
        listitem.set_url(url)

        item_info = links_result['playlist']['items'][0]
        if item_info.get('errorMessage') is not None:
            plugin.notify_error(plugin.remove_html(item_info['errorMessage']), True)
            playlist_url = None
        else:
            playlist_url = _get_video_path(item_info['videos'])

        if playlist_url is None:
            succeeded = False
        else:
            listitem.set_path(playlist_url)

        if is_strm \
                and succeeded:
            listitem.__class__ = EmptyListItem

        if succeeded:
            plugin.send_notification('OnPlay', data)

        plugin.resolve_url(listitem.get_item(), succeeded)


def _get_video_path(links):
    video_quality = plugin.get_setting('video_quality')

    path = ''
    if video_quality == 0:
        if links.get('hls') is not None:
            path = links['hls']
        else:
            video_quality = 10

    if not path:
        mp4 = links['mp4']
        if (not path or video_quality >= 1) and mp4.get('240p') is not None:
            path = mp4['240p']
        if (not path or video_quality >= 1) and mp4.get('360p') is not None:
            path = mp4['360p']
        if (not path or video_quality >= 2) and mp4.get('480p') is not None:
            path = mp4['480p']
        if (not path or video_quality >= 3) and mp4.get('720p') is not None:
            path = mp4['720p']
        if (not path or video_quality >= 4) and mp4.get('1080p') is not None:
            path = mp4['1080p']

    if path:
        path = 'https:{0}'.format(path)
    return path


def _get_pages(page_params, offset, limit, total, action):
    # Parameters for previous page
    if offset >= limit:
        prev_offset = offset - limit
        if prev_offset > 0:
            prev_page = {'offset': prev_offset,
                         'limit': limit,
                         }
            prev_page.update(page_params)
        else:
            prev_page = page_params
    else:
        prev_page = None

    # Parameters for next page
    next_offset = offset + limit
    if total > next_offset:
        next_page = {'offset': next_offset,
                     'limit': limit,
                     }
        next_page.update(page_params)
    else:
        next_page = None

    pages = {'action': action,
             'prev': prev_page,
             'next': next_page,
             }

    return pages


def _category_items():
    # icons
    movie_icon = plugin.get_image('DefaultMovies.png')
    musicvideos_icon = plugin.get_image('DefaultMusicVideos.png')
    tvshow_icon = plugin.get_image('DefaultTVShows.png')
    favorite_icon = plugin.get_image('DefaultFavourites.png')

    # sort methods
    default_sort_method = {'sortMethod': xbmcplugin.SORT_METHOD_UNSORTED, 'label2Mask': '%Y / %O'}
    musicvideos_sort_method = {'sortMethod': xbmcplugin.SORT_METHOD_UNSORTED, 'label2Mask': '%Y'}

    try:
        category_result = Tvigle().category()
    except (simplemedia.WebClientError, TvigleError) as e:
        plugin.notify_error(e)
    else:

        for item in category_result:
            if item['id'] in [49]:
                content = 'videos'
                icon = movie_icon
                sort_method = default_sort_method
            elif item['id'] in [89]:
                content = 'musicvideos'
                icon = musicvideos_icon
                sort_method = musicvideos_sort_method
            elif item['id'] in [22, 81, 72, 68]:
                content = 'tvshows'
                icon = tvshow_icon
                sort_method = default_sort_method
            else:
                content = 'movies'
                icon = movie_icon
                sort_method = default_sort_method

            yield {'id': item['id'],
                   'name': item['name'],
                   'slug': item['slug'],
                   'icon': icon,
                   'content': content,
                   'description': item['smarttv_description'],
                   'image': item['smarttv_image'] or plugin.fanart,
                   'sort_method': sort_method,
                   'account_method': False,
                   }

    if plugin.get_setting('pk'):

        account_items = [{'name': _('Favorites'), 'slug': 'favorite', 'content': 'movies'},
                         # {'name': _('Purchased'), 'slug': 'purchase', 'content': 'movies'},
                         {'name': _('Viewed'), 'slug': 'history', 'content': 'videos'},
                         ]
        for item in account_items:
            yield {'id': item['slug'],
                   'name': item['name'],
                   'slug': item['slug'],
                   'icon': favorite_icon,
                   'content': item['content'],
                   'description': '',
                   'image': plugin.fanart,
                   'sort_method': default_sort_method,
                   'account_method': True,
                   }


@plugin.route('/search/history/')
def search_history():
    result = {'items': plugin.search_history_items(),
              'content': '',
              'category': ' / '.join([plugin.name, _('Search')]),
              }

    plugin.create_directory(**result)


@plugin.route('/search/remove/<int:index>')
def search_remove(index):
    plugin.search_history_remove(index)


@plugin.route('/search/clear')
def search_clear():
    plugin.search_history_clear()


@plugin.route('/search', 'search_old')
@plugin.route('/search/')
def search():
    keyword = plugin.params.keyword or ''
    usearch = plugin.params.usearch or ''
    is_usearch = (usearch.lower() == 'true')

    if not keyword:
        keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
                and not is_usearch:
            plugin.update_search_history(keyword)

            url = plugin.url_for('search', keyword=keyword)
            xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword is not None:
        offset = plugin.params.offset or '0'
        offset = int(offset)

        limit = plugin.params.limit
        if not limit:
            limit = plugin.get_setting('limit', False)
        limit = int(limit)

        try:
            search_result = Tvigle().product_search(keyword, offset, limit)
        except (TvigleError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:
            page_params = {'keyword': keyword,
                           }

            pages = _get_pages(page_params, offset, limit, search_result['count'], 'search')

            category_parts = [_('Search'), keyword,
                              '{0} {1}'.format(_('Page'), int(offset / limit) + 1),
                              ]

            product_items = search_result['results']

            result = {'items': _list_category(product_items, pages),
                      'total_items': len(product_items),
                      'content': 'movies',
                      'category': ' / '.join(category_parts),
                      'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_UNSORTED, 'label2Mask': '%Y / %O'},
                      'update_listing': (offset > 0),
                      }
            plugin.create_directory(**result)


@plugin.route('/favorites_add')
def favorites_add():
    product_id = plugin.params.product_id

    try:
        Tvigle().product_favorite_add(product_id)
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('Successfully added to \'Favorites\''))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.route('/favorites_rem')
def favorites_rem():
    product_id = plugin.params.product_id

    try:
        Tvigle().product_favorite_rem(product_id)
    except (TvigleError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('Successfully removed from \'Favorites\''))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.mem_cached(180)
def _category_info(cat_slug):
    for item in _category_items():
        if cat_slug == item['slug']:
            return item


def _get_group_items(product_item):
    group_items = product_item.get('groups', [])
    if not group_items:
        item = {'id': None,
                'name': '{0} 1'.format(_('Season')),
                'slug': 'season-1',
                'priority': 2,
                'videos_count': product_item['videos_count']
                }
        group_items.append(item)

    return group_items


def _get_group_info(product_item, group_id):
    group_items = _get_group_items(product_item)

    for item in group_items:
        if item['id'] == group_id:
            return item


def _use_atl_names():
    return plugin.params.get('atl', '') == '1' \
           or plugin.get_setting('use_atl_names')


def _get_listitem_url(video_info, use_atl_names=False):
    ext_dir_params = {}
    ext_item_params = {}
    if use_atl_names:
        ext_dir_params['atl'] = 1
        ext_item_params['strm'] = 1

    if video_info.mediatype in ['movie', 'musicvideo', 'video', 'episode']:
        url = plugin.url_for('play_video', video_id=video_info.video_id, **ext_item_params)
    elif video_info.mediatype == 'tvshow':
        url = plugin.url_for('seasons', product_id=video_info.product_id, **ext_dir_params)
    elif video_info.mediatype == 'season':
        if video_info.group_id is not None:
            url = plugin.url_for('episodes', product_id=video_info.product_id, group_id=video_info.group_id,
                                 **ext_dir_params)
        else:
            url = plugin.url_for('episodes_empty_group', product_id=video_info.product_id, **ext_dir_params)
    else:
        url = None

    return url


def _page_items(pages):
    if pages['prev'] is not None:
        url = plugin.url_for(pages['action'], **pages['prev'])
        listitem = {'label': _('Previous page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem

    if pages['next'] is not None:
        url = plugin.url_for(pages['action'], **pages['next'])
        listitem = {'label': _('Next page...'),
                    'fanart': plugin.fanart,
                    'is_folder': True,
                    'url': url,
                    'properties': {'SpecialSort': 'bottom'},
                    'content_lookup': False,
                    }
        yield listitem


if __name__ == '__main__':
    plugin.run()
