# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
from future.utils import iteritems
from simplemedia import Addon

from .libs import Tvigle, TvigleError

__all__ = ['Tvigle', 'TvigleError', 'ProductInfo', 'SeasonInfo', 'VideoInfo', 'EmptyListItem', 'ListItem']

addon = Addon()
_ = addon.initialize_gettext()


class ProductInfo(simplemedia.VideoInfo):
    _path = None  # type: str
    _playcount = None  # type: int
    _video = None  # type: dict
    _group = None  # type: dict
    _mediatype = None  # type: (str, None)
    _for_play = False  # type: bool

    def __init__(self, data, for_play=False, atl_names=False, for_history=False):
        self._data = data

        self._for_play = for_play
        self._for_history = for_history
        self._atl_names = atl_names and not for_play

        self.product_id = data['id']
        self.video_id = data.get('first_video_id')

    @property
    def genre(self):
        genres = self._data.get('genres')
        if genres is not None:
            return genres

    @property
    def country(self):
        countries = self._data.get('countries')
        if countries is not None:
            return countries

    @property
    def year(self):
        release_year = self._data.get('release_year')
        if release_year is not None:
            return int(release_year)

    @property
    def episode(self):
        if self.mediatype in ['tvshow', 'season']:
            return self._data['videos_count']

    @property
    def season(self):
        if self.mediatype in ['tvshow', 'season']:
            return len(self._data['groups']) or 1

    @property
    def playcount(self):
        return self._playcount

    @property
    def mpaa(self):
        age_restrictions = self._data.get('age_restrictions')
        if age_restrictions is not None:
            return age_restrictions

    @property
    def plot(self):
        description = addon.remove_html(self._data['description'])

        return description

    @property
    def title(self):

        return self._title()

    @property
    def original_title(self):
        if self.mediatype in ['movie', 'tvshow', 'video']:
            if self._data['name']:
                return self._data['name']

    @property
    def tvshowtitle(self):
        if self.mediatype in ['tvshow', 'season', 'episode']:
            if self._data['name']:
                return self._data['name']

    @property
    def artist(self):
        if self.mediatype == 'musicvideo':
            return self._musicvideo_info()['artist']

    @property
    def path(self):
        return self._path

    @property
    def mediatype(self):
        _mediatype = getattr(self, '_mediatype', None)
        if _mediatype is None:
            video_count = self._data['videos_count']
            if video_count > 1:
                _mediatype = 'tvshow'
            elif self._musicvideo():
                _mediatype = 'musicvideo'
            elif self._videotype():
                _mediatype = 'video'
            else:
                _mediatype = 'movie'

            self._mediatype = _mediatype

        return self._mediatype

    def _musicvideo(self):
        return self._data['kind'] == 'music' \
               and (self._data['name'].find('—')
                    or self._data['name'].find('—'))

    def _videotype(self):
        return self._data['kind'] == 'trailer'

    def _musicvideo_info(self):
        artists = None
        title = self._data['name']

        separator = None
        for _separator in ['—', '-']:
            if title.find(_separator) >= 0:
                separator = _separator
                break

        if separator is not None:
            title_parts = title.split(separator)
            artist_string = title_parts[0].strip()
            title = title_parts[1].strip()

            artists = []
            artist_parts = artist_string.split(',')
            for artist in artist_parts:

                feat_sep = None
                for _feat_sep in ['feat.', 'feat']:
                    if artist.find(_feat_sep) >= 0:
                        feat_sep = _feat_sep
                        break

                if feat_sep is not None:
                    _artist_parts = artist.split(feat_sep)
                    for _artist in _artist_parts:
                        artists.append(_artist.strip())
                else:
                    artists.append(artist.strip())

        return {'title': title,
                'artist': artists}

    def _episode_title(self):
        title = self._video['name']

        title_removed = False
        if title.find(self.tvshowtitle) == 0:
            title = title.replace(self.tvshowtitle, '').strip()
            title_removed = True

        index = title.find('Серия')
        if index >= 0:
            title_parts = title.split('Серия')
            if title_removed \
                    and index > 3 \
                    and len(title_parts) > 1:
                title = title_parts[0].strip()
            else:
                title = title_parts[1].strip()
        elif title.find('серия'):
            title_parts = title.split('серия')
            if len(title_parts) > 1:
                title = title_parts[1].strip()
        else:
            return title

        episode_number = '{0}'.format(self.episode)
        if title.find(episode_number) == 0:
            title = title.replace(episode_number, '').strip()

        if self._atl_names:
            return title

        if not title:
            title = '{0} {1}'.format(_('Episode'), self.episode)

        return title

    def _title(self):
        if self.mediatype in ['movie', 'video', 'tvshow']:
            return self._data['name']
        elif self.mediatype == 'season':
            return self._group['name']
        elif self.mediatype == 'episode':
            if self._for_history:
                return self._video['name']
            else:
                return self._episode_title()
        elif self.mediatype == 'musicvideo':
            return self._musicvideo_info()['title']

    def _atl_title(self):

        title_parts = []
        if self.mediatype == 'movie':
            title_parts.append(self.original_title)
            if self.year is not None:
                title_parts.append('({0})'.format(self.year))

        elif self.mediatype == 'episode':
            title_parts.append(self.tvshowtitle)
            title_parts.append('s%02de%02d' % (self.season, self.episode))
            episode_title = self._episode_title()
            if episode_title:
                title_parts.append(episode_title)
        else:
            title_parts.append(self._title())

        return ' '.join(title_parts)

    def get_poster(self):
        return self._data.get('poster', '')

    def get_fanart(self):
        return self._data.get('thumbnail', '')

    def get_thumb(self):
        return self._data.get('thumbnail', '')

    def set_path(self, path):
        self._path = path

    def set_playcount(self, playcount):
        self._playcount = playcount

    @property
    def data(self):
        return self._data

    @property
    def for_play(self):
        return self._for_play


class SeasonInfo(ProductInfo):

    def __init__(self, data, group):
        super(SeasonInfo, self).__init__(data)

        self._group = group

        self.group_id = group['id']

    @property
    def mediatype(self):
        return "season"


class VideoInfo(ProductInfo):

    def __init__(self, data, video, for_play=False, atl_names=False, for_history=False):

        super(VideoInfo, self).__init__(data, for_play, atl_names, for_history)

        self._video = video

        self.video_id = video['id']
        self.is_paid = (video['is_paid'] and not video['can_play'])

    @property
    def episode(self):
        if self.mediatype == 'episode':
            if self._video['series'] is not None:
                return self._video['series']
            else:
                return self._episode_from_name()

    @property
    def season(self):
        if self.mediatype == 'episode':
            return self._video['season'] or 1

    @property
    def cast(self):
        return self.get_persons('actor')

    @property
    def director(self):
        return self.get_persons('director')

    @property
    def mpaa(self):
        age_restrictions = self._video.get('age_restrictions')
        if age_restrictions is not None:
            return age_restrictions

    @property
    def plot(self):
        if self.mediatype == 'episode':
            description = addon.remove_html(self._video['description'])

            return description

        return super(VideoInfo, self).plot

    @property
    def title(self):

        if self._atl_names:
            title = self._atl_title()
        else:
            title = self._title()

        postfix = self._title_postfix()
        if postfix:
            title = '{0} [{1}]'.format(title, postfix)

        return title

    @property
    def duration(self):
        if self.mediatype in ['movie', 'musicvideo', 'episode', 'video'] \
                and self._video.get('duration') is not None:
            return self._video['duration'] / 1000

    @property
    def writer(self):
        return self.get_persons('write')

    @property
    def mediatype(self):
        _mediatype = getattr(self, '_mediatype', None)
        if _mediatype is None:
            video_count = self._data['videos_count']
            if video_count > 1:
                _mediatype = 'episode'
            elif self._musicvideo():
                _mediatype = 'musicvideo'
            elif self._videotype():
                _mediatype = 'video'
            else:
                _mediatype = 'movie'
            self._mediatype = _mediatype

        return self._mediatype

    def get_thumb(self):
        return self._video.get('thumbnail', '')

    def get_persons(self, persons):

        items = self._video['persons'].get(persons)
        if items is not None:
            return [val for key, val in iteritems(items)]

    def _title_postfix(self):

        if self._video['is_paid'] \
                and not self._video['can_play']:
            tariffs = []
            for tariff in self._video['tariffs']:
                if not tariff['title'] in tariffs:
                    tariffs.append(tariff['title'])

            return ' / '.join(tariffs)

        return ''

    def _episode_from_name(self):

        title = self._video['name']

        episode = None
        index = title.find('Серия')
        if index >= 0:
            episode = title[index:].split(' ')[1]

        index = title.find('серия')
        if episode is None \
                and index >= 0:
            episode = title[:index - 1].split(' ')[-1]

        index = title.find('Выпуск')
        if episode is None \
                and index >= 0:
            episode = title[index:].split(' ')[1]

        if episode is not None:
            return int(episode)


class EmptyListItem(simplemedia.ListItemInfo):
    plugin = None

    _url = None
    _path = None
    _info = None

    @property
    def path(self):
        return self._path

    @property
    def url(self):
        return self._url

    def set_url(self, url):
        self._url = url

        if isinstance(self._info, ProductInfo):
            self._info.set_path(url)

    def set_path(self, path):
        self._path = path


class ListItem(EmptyListItem):
    _offset = None
    _is_favorite = None

    def __init__(self, video_info, complete=False):

        self._info = video_info

        self._data = video_info.data
        self._mediatype = video_info.mediatype
        self._for_play = video_info.for_play

        self._complete = complete
        self._default_rating = 'kinopoisk'

        self.product_id = video_info.product_id
        self.video_id = video_info.video_id

        if self.plugin is not None \
                and self.plugin.get_setting('pk') \
                and self.video_id is not None:
            api = Tvigle()
            try:
                video_settings = api.video_user_settings(self.video_id)
            except (TvigleError, simplemedia.WebClientError) as e:
                addon.notify_error(e)
            else:
                self._offset = video_settings['offset']
                self._is_favorite = video_settings['is_favorite']

        if self._mediatype in ['movie', 'episode', 'video', 'musicvideo']:
            if not self._complete \
                    and self._offset is not None \
                    and self._info.duration is not None:
                self._complete = (self._offset >= (self._info.duration * 0.9))

            if self._complete:
                self._info.set_playcount(1)

    @property
    def label(self):
        return self._info.title

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        return self._mediatype in ['movie', 'episode', 'musicvideo', 'video']

    @property
    def context_menu(self):
        context_menu = []

        if self._is_favorite is not None \
                and self.plugin is not None:
            if self._is_favorite:
                title = self.plugin.gettext('Remove from \'Favorites\'')
                url = self.plugin.url_for('favorites_rem', product_id=self.product_id)
            else:
                title = self.plugin.gettext('Add to \'Favorites\'')
                url = self.plugin.url_for('favorites_add', product_id=self.product_id)

            context_menu.append((title, 'RunPlugin({0})'.format(url)))

        return context_menu

    @property
    def properties(self):
        properties = {}

        if self._mediatype == 'tvshow':
            properties['TotalSeasons'] = '{0}'.format(self._info.season)
            properties['TotalEpisodes'] = '{0}'.format(self._info.episode)
            properties['WatchedEpisodes'] = '0'
            properties['UnWatchedEpisodes'] = '{0}'.format(self._info.episode)
            properties['NumEpisodes'] = '{0}'.format(self._info.episode)

        if not self._complete \
                and self._info.duration is not None \
                and self._offset is not None:
            properties['TotalTime'] = '{0}'.format(self._info.duration)
            properties['ResumeTime'] = '{0}'.format(self._offset)

        return properties

    @property
    def online_db_ids(self):
        db_ids = {'tvigle': str(self.product_id)}

        return db_ids

    @property
    def ratings(self):

        if self._info.mediatype in ['movie', 'tvshow', 'video', 'musicvideo']:
            ratings = [self._make_rating('kinopoisk', self._data['kinopoisk_rating']),
                       ]

            for rating in ratings:
                rating['defaultt'] = (rating['type'] == self._default_rating)

            return ratings

    @staticmethod
    def _make_rating(type_, rating, votes=0):
        if rating:
            rating = float(rating)
        else:
            rating = 0

        return {'type': type_,
                'rating': rating,
                'votes': votes,
                'defaultt': False,
                }

    @property
    def art(self):
        art = {}
        if self._mediatype in ['tvshow', 'movie', 'musicvideo', 'video']:
            art['poster'] = self._info.get_poster()
        elif self._mediatype in ['season', 'episode']:
            art['tvshow.poster'] = self._info.get_poster()

        return art

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season', 'video']:
            return self._info.get_poster()
        elif self._mediatype in ['episode', 'musicvideo']:
            return self._info.get_thumb()

    @property
    def fanart(self):
        return self._info.get_fanart()

    @property
    def info(self):
        return {'video': self._info.get_info()}

    @property
    def season(self):
        if self._mediatype in ['season', 'episode']:
            return {'number': self._info.season}
