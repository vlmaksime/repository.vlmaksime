# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia

from .utilities import Utilities
from .utilities import plugin

__all__ = ['MainMenuItem', 'ItemInfo', 'SeasonInfo', 'VideoInfo', 'EmptyListItem', 'ListItem']

addon = simplemedia.Addon()
_ = addon.initialize_gettext()


class ItemInfo(simplemedia.VideoInfo):
    _path = None
    _trailer = None
    _mediatype = None
    content_id = ''
    serial_id = ''

    def __init__(self, item_info, for_play=False, atl_names=False):
        self._item_info = item_info

        self._for_play = for_play
        self._atl_names = atl_names and not for_play

        self.content_id = item_info['id']
        self.serial_id = item_info['serial_id']

    @property
    def genre(self):
        return self._split_string(self._item_info['genres'])

    @property
    def country(self):
        return self._split_string(self._item_info['country'])

    @property
    def year(self):
        if not self.mediatype in ['tvshow'] \
                and self._item_info['year'] != '0':
            return int(self._item_info['year'])
        elif self._item_info['date_premiere']:
            return int(self._item_info['date_premiere'][0:4])
        return None

    @property
    def episode(self):
        if self.mediatype == 'tvshow':
            total_episodes = len(self._item_info['series'])
            return total_episodes
        return None

    @property
    def season(self):
        if self.mediatype in ['tvshow', 'season'] \
                and self.item_info.get('serial_count_seasons') is not None:
            return int(self.item_info['serial_count_seasons'])
        elif self.mediatype in ['episode']:
            return int(self._item_info['season_number'])
        return None

    @property
    def cast(self):
        return self._split_string(self._item_info['actors'])

    @property
    def director(self):
        return self._split_string(self._item_info['director'])

    @property
    def mpaa(self):
        return self._item_info['age']

    @property
    def plot(self):
        if self.mediatype in ['tvshow', 'movie', 'season']:
            return self._item_info['description']
        return None

    @property
    def title(self):
        if self._atl_names:
            title = self._atl_title()
        else:
            title = self._title()
        return title

    @property
    def original_title(self):
        if self.mediatype in ['tvshow', 'movie']:
            if self._item_info['original_name']:
                title = self._item_info['original_name']
            else:
                title = self._item_info['name']
            return title
        return None

    @property
    def duration(self):
        if self.mediatype in ['movie']:
            if self._item_info['time']:
                time = int(self._item_info['time']) * 60
                return time
        return None

    @property
    def tvshowtitle(self):
        if self.mediatype in ['tvshow', 'season', 'episode']:
            return self._item_info['serial_name']
        return None

    @property
    def premiered(self):
        if self.mediatype in ['movie', 'tvshow']:
            return self._item_info['date_premiere']
        return None

    @property
    def path(self):
        return self._path

    @property
    def trailer(self):
        return self._trailer

    @property
    def dateadded(self):
        if self.mediatype in ['movie', 'tvshow']:
            import datetime
            timestamp = self._item_info['added']
            datetime_object = datetime.datetime.fromtimestamp(timestamp)
            formatted_date = datetime_object.strftime('%Y-%m-%d')
            return formatted_date
        return None

    @property
    def mediatype(self):
        _mediatype = self._mediatype
        if _mediatype is None:
            if Utilities.is_movie(self._item_info):
                _mediatype = 'movie'
            else:
                _mediatype = 'tvshow'

            self._mediatype = _mediatype

        return self._mediatype

    def _title(self):
        # if self._item_info['quality'] \
        #         and not self._for_play:
        #     title = '{0} [{1}]'.format(self._item_info['title'], self._item_info['quality'])
        # else:
        #     title = self._item_info['name']
        if self.mediatype in ['tvshow', 'season'] \
                and self._item_info.get('serial_name') is not None:
            title = self._item_info['serial_name']
        else:
            title = self._item_info['name']

        return title

    def _atl_title(self):

        title_parts = []
        if self.mediatype == 'movie':
            title_parts.append(self.original_title)
            if self.year is not None:
                title_parts.append('({0})'.format(self.year))

        elif self.mediatype == 'episode':
            if self._item_info['original_title']:
                title = self._item_info['original_title']
            else:
                title = self._item_info['title']
            title_parts.append(title)
            title_parts.append('s%02de%02d' % (self.season, self.episode))
        else:
            title_parts.append(self._title())

        return '.'.join(title_parts)

    def get_poster(self):
        return self._item_info['cover']

    @staticmethod
    def _split_string(string):
        result = []
        parts = string.split(',')
        for part in parts:
            if part:
                result.append(part.strip())

        if len(result) > 0:
            return result

        return None

    @staticmethod
    def get_thumb():
        return None

    def get_fanart(self):
        return self.get_thumb()

    def set_path(self, path):
        self._path = path

    def set_trailer(self, trailer):
        self._trailer = trailer

    @property
    def item_info(self):
        return self._item_info

    @property
    def for_play(self):
        return self._for_play

    def get_section(self):
        return self._item_info['section']


class SeasonInfo(ItemInfo):
    _season = None
    _episodes = None

    def __init__(self, item_info):
        super(SeasonInfo, self).__init__(item_info, False, False)

        self._season = int(item_info['season_number'])
        self._episodes = len(item_info['series'])
        self._mediatype = 'season'

    @property
    def episode(self):
        return self._episodes

    @property
    def season(self):
        return max(1, self._season)

    @property
    def title(self):
        return '{0} {1}'.format(_('Season'), self._season)

    def get_season(self):
        return self._season


class VideoInfo(ItemInfo):
    _episode = None
    _season = None

    def __init__(self, item_info, for_play=False, atl_names=False):
        super(VideoInfo, self).__init__(item_info, for_play, atl_names)

    @property
    def episode(self):
        if self.mediatype == 'episode':
            return self._episode
        return None

    @property
    def season(self):
        if self.mediatype == 'episode':
            return max(1, self._season)
        return None

    @property
    def originaltitle(self):
        if self.mediatype == 'episode':
            return self.title
        else:
            return super(VideoInfo, self).originaltitle

    #
    # @property
    # def duration(self):
    #     return self._item_info['duration'] * 60

    @property
    def mediatype(self):
        _mediatype = self._mediatype
        if _mediatype is None:
            _mediatype = super(VideoInfo, self).mediatype
            if _mediatype == 'tvshow':
                _mediatype = 'episode'

            self._mediatype = _mediatype

        return self._mediatype

    def _title(self):
        if self.mediatype == 'episode':
            title = '{0} {1}'.format(_('Episode'), self.episode)
        else:
            title = super(VideoInfo, self)._title()

        return title

    def set_episode_info(self, season, episode):
        self._season = season
        self._episode = episode

    def get_season(self):
        return self._season

    def get_episode(self):
        return self._episode


class EmptyListItem(simplemedia.ListItemInfo):
    _url = None
    _path = None
    _info = None

    @property
    def path(self):
        return self._path

    @property
    def url(self):
        return self._url

    def set_url(self, url):
        self._url = url

    def set_path(self, path):
        self._path = path


class ListItem(EmptyListItem):
    _properties = None
    _context_menu = None

    def __init__(self, video_info):

        self._info = video_info

        self._item_info = video_info.item_info
        self._mediatype = video_info.mediatype
        self._for_play = video_info.for_play

        self.content_id = video_info.content_id

    @property
    def label(self):
        return self._info.title

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        if isinstance(self._info, VideoInfo):
            return False
        else:
            return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        if isinstance(self._info, VideoInfo):
            return True
        else:
            return self._mediatype in ['movie', 'episode']

    @property
    def art(self):
        art = {}

        if self._mediatype in ['season', 'episode']:
            art['tvshow.poster'] = self._info.get_poster()
        elif self._mediatype in ['tvshow', 'movie']:
            art['poster'] = self._info.get_poster()

        return art

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self._info.get_poster()
        elif self._mediatype in ['episode']:
            return self._info.get_thumb()
        return None

    @property
    def fanart(self):
        return self._info.get_fanart()

    @property
    def info(self):
        return {'video': self._info.get_info()}

    @property
    def context_menu(self):
        return self._context_menu

    @property
    def properties(self):
        properties = {}

        if isinstance(self._properties, dict):
            properties.update(self._properties)

        if self._mediatype == 'season':
            properties['TotalSeasons'] = '{0}'.format(self._info.season)
            properties['TotalEpisodes'] = '{0}'.format(self._info.episode)
            properties['WatchedEpisodes'] = '0'
            properties['UnWatchedEpisodes'] = '{0}'.format(self._info.episode)
            properties['NumEpisodes'] = '{0}'.format(self._info.episode)

        return properties

    @property
    def season(self):
        if self._mediatype in ['season', 'episode'] and self._info.season is not None:
            return {'number': self._info.season}
        return None

    @property
    def ratings(self):
        if self._mediatype in ['movie', 'tvshow']:
            default_source = self._get_rating_source()
            items = []
            for rating in self._rating_sources():
                rating_item = self._make_rating(self._item_info, **rating)
                rating_item['defaultt'] = (rating_item['type'] == default_source)
                items.append(rating_item)
            return items
        return None

    @staticmethod
    def _get_rating_source():
        rating_source = addon.get_setting('video_rating')
        if rating_source == 0:
            return 'imdb'
        elif rating_source == 1:
            return 'kinopoisk'
        return None

    @staticmethod
    def _rating_sources():
        yield {'rating_source': 'kinopoisk', 'field': 'rating_kinopoisk', }
        yield {'rating_source': 'imdb', 'field': 'rating_imdb', }

    @staticmethod
    def _make_rating(item, rating_source, field):
        rating_info = item.get(field)

        if rating_info is not None and rating_info['rating']:
            rating = float(rating_info['rating'])
        else:
            rating = 0

        if rating_info is not None and rating_info['count']:
            votes = int(rating_info['count'])
        else:
            votes = 0

        return {'type': rating_source,
                'rating': rating,
                'votes': votes,
                'defaultt': False, }

    def set_properties(self, properties):
        self._properties = properties

    def set_context_menu(self, context_menu):
        self._context_menu = context_menu


class MainMenuItem(EmptyListItem):

    def __init__(self, section_info):
        self._info = section_info

    @property
    def label(self):
        return self._info.get('label')

    @property
    def content_lookup(self):
        return False

    @property
    def icon(self):
        return self._info.get('icon')

    @property
    def fanart(self):
        return plugin.fanart
