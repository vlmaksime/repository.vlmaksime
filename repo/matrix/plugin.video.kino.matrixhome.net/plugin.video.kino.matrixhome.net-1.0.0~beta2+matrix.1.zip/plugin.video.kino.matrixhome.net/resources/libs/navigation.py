# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
import xbmc
import xbmcplugin
from simplemedia import py2_decode

from .listitems import ItemInfo, SeasonInfo, VideoInfo, EmptyListItem, ListItem, MainMenuItem
from .utilities import Utilities
from .utilities import plugin, _
from .web import (Kinozal, KinozalError)


class KinozalCatalogs(object):
    @classmethod
    def root(cls):
        plugin.create_directory(cls._root_items(), content='', category=plugin.name)

    @classmethod
    def _root_items(cls):

        sections = Utilities.get_sections()
        for section_item in sections:

            if not section_item.get('visible', False):
                continue

            url = plugin.url_for(section_item['section'])

            item_info = MainMenuItem(section_item)
            item_info.set_url(url)

            yield item_info.get_item()

    @classmethod
    def catalog(cls, section):

        section_item = Utilities.get_section_item(section)

        limit = plugin.params.get('limit')
        if limit is None:
            limit = plugin.get_setting('limit')

        page = plugin.params.get('page', '1')

        try:
            catalog_info = Kinozal().catalog(section_item['section'], limit, page)
        except (KinozalError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:

            # filters_items = Filters.get_filters_items(section_item)
            filters_items = []
            filters = []

            # wm_params = {'filters': filters,
            #              }
            #
            # wm_properties = {'wm_link': plugin.url_for(section_item['section'], wm_link=1, **wm_params),
            #                  'wm_addon': plugin.id,
            #                  'wm_label': section_item['label'],
            #                  }
            wm_properties = {}

            category_parts = [section_item['label'],
                              '{0} {1}'.format(_('Page'), page),
                              ]

            catalog_items = catalog_info['results']
            total_items = len(catalog_items)

            pages = Utilities.get_pages(total_items, page, section, limit, filters=filters)

            total_items = len(catalog_items) + len(filters_items) + len(pages)

            result = {'items': cls._list_items(catalog_items, wm_properties, filters_items, pages),
                      'total_items': total_items,
                      'content': section_item['content'],
                      'category': ' / '.join(category_parts),
                      'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
                      'update_listing': (page != '1'),
                      }
            plugin.create_directory(**result)

    @classmethod
    def _list_items(cls, items, wm_properties=None, filters=None, pages=None):

        filters = filters or []
        pages = pages or []

        wm_link = (plugin.params.get('wm_link') == '1')

        if not wm_link:
            for filter_item in filters:
                yield filter_item.get_item()

        properties = {}
        if wm_properties is not None:
            properties.update(wm_properties or {})

        for item in items:

            if not isinstance(item, dict):
                continue

            item_info = ItemInfo(item)

            listitem = ListItem(item_info)

            url = cls._get_listitem_url(item_info)

            listitem.set_url(url)
            listitem.set_properties(properties)
            listitem.set_context_menu(cls._get_context_menu(item))

            yield listitem.get_item()

        if not wm_link:
            for page in pages:
                yield page

    @classmethod
    def serial_seasons(cls, content_id):

        try:
            content_info = Kinozal().serial_info(content_id)
        except (KinozalError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:

            seasons = content_info['results']

            result = {'items': cls._list_serial_seasons(seasons),
                      'content': 'seasons',
                      'category': seasons[0]['serial_name'],
                      'sort_methods': xbmcplugin.SORT_METHOD_TITLE,
                      }

            plugin.create_directory(**result)

    @classmethod
    def _list_serial_seasons(cls, items):
        use_atl_names = Utilities.use_atl_names()

        for item in items:
            season_info = SeasonInfo(item)

            url = cls._get_listitem_url(season_info, use_atl_names)
            listitem = ListItem(season_info)
            listitem.set_url(url)

            yield listitem.get_item()

    @classmethod
    def serial_episodes(cls, content_id, ):

        try:
            content_info = Kinozal().serial_info(content_id)
        except (KinozalError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:

            season = plugin.params.s

            seasons = content_info['results']

            for season_info in seasons:
                if not season_info['season_number'] == season:
                    continue

                use_atl_names = Utilities.use_atl_names()
                if use_atl_names:
                    sort_methods = xbmcplugin.SORT_METHOD_TITLE
                else:
                    sort_methods = xbmcplugin.SORT_METHOD_EPISODE

                result = {'items': cls._list_episodes_items(season_info),
                          'content': 'episodes',
                          'category': ' / '.join([season_info['serial_name'], '{0} {1}'.format(_('Season'), season)]),
                          'sort_methods': sort_methods,
                          }

                plugin.create_directory(**result)


    @classmethod
    def season_episodes(cls, content_id):

        try:
            season_info = Kinozal().video_info(content_id)
        except (KinozalError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:

            use_atl_names = Utilities.use_atl_names()
            if use_atl_names:
                sort_methods = xbmcplugin.SORT_METHOD_TITLE
            else:
                sort_methods = xbmcplugin.SORT_METHOD_EPISODE

            result = {'items': cls._list_episodes_items(season_info),
                      'content': 'episodes',
                      'category': season_info['name'],
                      'sort_methods': sort_methods,
                      }

            plugin.create_directory(**result)

    @classmethod
    def _list_episodes_items(cls, item):
        use_atl_names = Utilities.use_atl_names()

        episode_info = VideoInfo(item, atl_names=use_atl_names)

        if item['season_number'] is not None:
            season = int(item['season_number'])
        else:
            season = 0

        for episode in item['series']:
            episode_info.set_episode_info(season, int(episode))

            listitem = ListItem(episode_info)

            url = cls._get_listitem_url(episode_info, use_atl_names)
            listitem.set_url(url)

            yield listitem.get_item()

    @classmethod
    def play_video(cls, content_id, episode=None):

        succeeded = True

        try:
            kinozal = Kinozal()
            video_info = kinozal.video_info(content_id)
        except (KinozalError, simplemedia.WebClientError) as e:
            plugin.notify_error(e, True)
            succeeded = False
            listitem = EmptyListItem()
        else:
            video_item = VideoInfo(video_info, True)
            if video_item.mediatype == 'episode':
                if video_info['season_number'] is not None:
                    season = int(video_info['season_number'])
                else:
                    season = 0
                episode = int(episode)
                video_item.set_episode_info(season, episode)

            listitem = ListItem(video_item)

            link_info = kinozal.video_link(video_item.content_id, episode)
            path = 'http:{0}'.format(link_info['results'])

            if path is None:
                plugin.resolve_url({}, False)
                return

            listitem.set_path(path)

            url = cls._get_listitem_url(video_item)
            listitem.set_url(url)

        if succeeded \
                and Utilities.is_strm():
            listitem.__class__ = EmptyListItem

        plugin.resolve_url(listitem.get_item(), succeeded)

    @staticmethod
    def search_history():
        result = {'items': plugin.search_history_items(),
                  'content': '',
                  'category': _('Search'),
                  'sort_methods': xbmcplugin.SORT_METHOD_NONE,
                  }

        plugin.create_directory(**result)

    @staticmethod
    def search_remove(index):
        plugin.search_history_remove(index)

    @staticmethod
    def search_clear():
        plugin.search_history_clear()

    @classmethod
    def search(cls):
        keyword = plugin.params.keyword or ''
        usearch = (plugin.params.usearch == 'True')

        new_search = (keyword == '')

        if not keyword:
            keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
                and new_search \
                and not usearch:
            with plugin.get_storage('__history__.pcl') as storage:
                _history = storage.get('history', [])
                _history.insert(0, {'keyword': keyword})
                if len(_history) > plugin.get_setting('history_length'):
                    _history.pop(-1)
                storage['history'] = _history

            plugin.create_directory([], succeeded=False)

            url = plugin.url_for('search', keyword=py2_decode(keyword))
            xbmc.executebuiltin('Container.Update("%s")' % url)

        elif keyword:

            page = plugin.params.get('page', '1')

            limit = plugin.params.get('limit')
            if limit is None:
                limit = plugin.get_setting('limit')

            try:
                search_info = Kinozal().search(keyword, limit, page)
            except (KinozalError, simplemedia.WebClientError) as e:
                plugin.notify_error(e)
                plugin.create_directory([], succeeded=False)
            else:
                catalog_items = search_info['results']
                total_items = len(catalog_items)

                pages = Utilities.get_pages(total_items, page, 'search', limit)

                total_items = total_items + len(pages)

                result = {'items': cls._list_items(catalog_items, pages=pages),
                          'total_items': total_items,
                          'content': 'movies',
                          'category': ' / '.join([_('Search'), keyword]),
                          'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
                          'update_listing': (page != '1'),
                          }

                plugin.create_directory(**result)

    @staticmethod
    def _get_context_menu(item):
        context_menu = []

        # if plugin.get_setting('user_login'):
        #     favorited = item.get('favorited')
        #     if favorited is not None:
        #         url = plugin.url_for('toogle_favorites', id=item['id'], value=(0 if favorited else 1))
        #         if item['favorited']:
        #             context_menu.append((_('Remove from Favorites'), 'RunPlugin({0})'.format(url)))
        #         else:
        #             context_menu.append((_('Add to Favorites'), 'RunPlugin({0})'.format(url)))
        #
        #     watch_later = item.get('watch_later')
        #     if watch_later is not None:
        #         url = plugin.url_for('toogle_watch_later', id=item['id'], value=(0 if watch_later else 1))
        #         if item['watch_later']:
        #             context_menu.append((_('Remove from Watch Later'), 'RunPlugin({0})'.format(url)))
        #         else:
        #             context_menu.append((_('Add to Watch Later'), 'RunPlugin({0})'.format(url)))

        return context_menu

    @staticmethod
    def _get_listitem_url(item_info, use_atl_names=False):

        url_params = {}

        if item_info.mediatype == 'tvshow' \
                and item_info.serial_id is not None:
            url_params['serial_id'] = item_info.serial_id
        elif item_info.mediatype == 'season':
            url_params['serial_id'] = item_info.serial_id
        else:
            url_params['content_id'] = item_info.content_id


        if use_atl_names \
                and item_info.mediatype in ['movie', 'episode']:
            url_params['strm'] = 1
        elif use_atl_names \
                and item_info.mediatype in ['tvshow', 'season']:
            url_params['atl'] = 1

        if item_info.mediatype == 'movie':
            return plugin.url_for('play_video', **url_params)

        elif item_info.mediatype == 'episode':
            return plugin.url_for('play_episode', episode=item_info.get_episode(),
                                  **url_params)

        elif item_info.mediatype == 'tvshow':
            if url_params.get('serial_id') is not None:
                return plugin.url_for('serial_seasons', **url_params)
            else:
                return plugin.url_for('season_episodes', **url_params)

        elif item_info.mediatype == 'season':
            return plugin.url_for('serial_episodes', s=item_info.get_season(),
                                  **url_params)
        return ''
