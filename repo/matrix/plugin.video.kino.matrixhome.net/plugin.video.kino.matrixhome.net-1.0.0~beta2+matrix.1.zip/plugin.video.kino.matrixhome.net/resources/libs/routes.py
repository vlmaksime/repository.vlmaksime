# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from .navigation import KinozalCatalogs
from .utilities import plugin

__all__ = ['plugin']


@plugin.route('/')
def root():
    KinozalCatalogs.root()


@plugin.route('/films/')
def films():
    KinozalCatalogs.catalog('films')


@plugin.route('/multfilms/')
def multfilms():
    KinozalCatalogs.catalog('multfilms')


@plugin.route('/serials/')
def serials():
    KinozalCatalogs.catalog('serials')


@plugin.route('/multserials/')
def multserials():
    KinozalCatalogs.catalog('multserials')


@plugin.route('/tv-shows/', 'tv-shows')
def tv_shows():
    KinozalCatalogs.catalog('tv-shows')


@plugin.route('/video/<content_id>')
def play_video(content_id):
    KinozalCatalogs.play_video(content_id)

@plugin.route('/video/<content_id>/<int:episode>')
def play_episode(content_id, episode):
    KinozalCatalogs.play_video(content_id, episode)

@plugin.route('/serial/<serial_id>')
def serial_seasons(serial_id):
    KinozalCatalogs.serial_seasons(serial_id)


@plugin.route('/serial/<serial_id>/episodes/')
def serial_episodes(serial_id):
    KinozalCatalogs.serial_episodes(serial_id)


@plugin.route('/season/<content_id>/episodes/')
def season_episodes(content_id):
    KinozalCatalogs.season_episodes(content_id)


@plugin.route('/search/history/')
def search_history():
    KinozalCatalogs.search_history()


@plugin.route('/search')
def search():
    KinozalCatalogs.search()


@plugin.route('/search/remove/<int:index>')
def search_remove(index):
    plugin.search_history_remove(index)


@plugin.route('/search/clear')
def search_clear():
    plugin.search_history_clear()
