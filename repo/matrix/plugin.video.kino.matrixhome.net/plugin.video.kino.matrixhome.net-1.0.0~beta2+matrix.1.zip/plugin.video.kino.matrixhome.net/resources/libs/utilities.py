# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
from simplemedia import py2_decode, WebClientError

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

__all__ = ['plugin', 'py2_decode', '_', 'WebClientError', 'Utilities']


class Utilities(object):

    @classmethod
    def get_sections(cls):
        movie_icon = plugin.get_image('DefaultMovies.png')
        tvshow_icon = plugin.get_image('DefaultTVShows.png')
        # favour_icon = plugin.get_image('DefaultFavourites.png')
        search_icon = plugin.get_image('DefaultAddonsSearch.png')

        # user_logged = (plugin.get_setting('user_login') != '')
        use_filters = False #plugin.get_setting('use_filters')

        s = [  # Main Sections
            cls._create_section_item('films', _('Movies'), movie_icon, 'movies',
                                     use_filters=use_filters),
            cls._create_section_item('multfilms', _('Cartoons'), movie_icon, 'movies',
                                     use_filters=use_filters),
            cls._create_section_item('serials', _('TV Series'), tvshow_icon, 'tvshows',
                                     use_filters=use_filters),
            cls._create_section_item('multserials', _('Cartoon Series'), tvshow_icon, 'tvshows',
                                     use_filters=use_filters),
            cls._create_section_item('tv-shows', _('TV Shows'), tvshow_icon, 'tvshows',
                                     use_filters=use_filters),
            cls._create_section_item('search_history', _('Search'), search_icon, ''),
        ]

        return s

    @staticmethod
    def _create_section_item(section, label, icon, content, visible=True, use_filters=False):
        section_item = {'section': section,
                        'label': label,
                        'icon': icon,
                        'content': content,
                        'visible': visible,
                        'use_filters': use_filters
                        }

        return section_item

    @classmethod
    def get_section_item(cls, section):
        sections = cls.get_sections()
        for item in sections:
            if item['section'] == section:
                return item
        return None

    @classmethod
    def get_pages(cls, total_items, page, section, limit, **kwargs):

        if not isinstance(page, int):
            page = int(page)

        page_params = kwargs or {}

        pages = []
        if page > 1:
            if page == 2:
                url = plugin.url_for(section, **page_params)
            else:
                url = plugin.url_for(section, page=(page - 1), **page_params)
            item_info = {'label': _('Previous page...'),
                         'url': url}
            pages.append(item_info)

        if limit <= total_items:
            url = plugin.url_for(section, page=(page + 1), **page_params)
            item_info = {'label': _('Next page...'),
                         'url': url}
            pages.append(item_info)

        return pages

    @staticmethod
    def use_atl_names():
        return plugin.params.get('atl', '').lower() == 'true' \
            or plugin.get_setting('use_atl_names')

    @staticmethod
    def is_strm():
        is_strm = plugin.params.get('strm') == '1' \
                  and plugin.kodi_major_version() >= '18'
        return is_strm

    @staticmethod
    def is_movie(content_info):
        return content_info['serial_id'] is None \
               and len(content_info['series']) == 0
