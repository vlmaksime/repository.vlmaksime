# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
import xbmc

from .kinozal import KinozalClient, KinozalError

addon = simplemedia.Addon()

__all__ = ['Kinozal', 'KinozalError']


class Kinozal(KinozalClient):

    def __init__(self):
        super(Kinozal, self).__init__()

        headers = self._client.headers
        if addon.kodi_major_version() >= '17':
            headers['User-Agent'] = xbmc.getUserAgent()

        self._client = simplemedia.WebClient(headers=headers)
