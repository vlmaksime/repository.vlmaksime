# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import requests
from future.utils import PY3

if PY3:
    basestring = str

__all__ = ['KinozalClient', 'KinozalError']


class KinozalError(Exception):

    def __init__(self, message, code=None):
        self.message = message
        self.code = code

        super(KinozalError, self).__init__(self.message)


class KinozalClient(object):
    _base_url = 'https://iptv.matrix.online/'

    def __init__(self):

        headers = {'Accept-Encoding': 'gzip',
                   'Accept': 'application/json',
                   'User-Agent': None
                   }

        self._client = requests.Session()
        self._client.headers.update(headers)

    def __del__(self):
        self._client.close()

    def _get(self, url, params=None, *args, **kwargs):
        params = params or {}
        params['client_id'] = 'akino'

        return self._client.get(url, params=params, *args, **kwargs)

    def _post(self, url, data=None, *args, **kwargs):
        return self._client.post(url, data=data, *args, **kwargs)

    @staticmethod
    def _extract_json(r):

        if not r.text:
            raise KinozalError('Server sent an empty response')

        try:
            j = r.json()
        except ValueError as e:
            raise KinozalError(e)

        if isinstance(j, dict) \
                and j.get('error') is not None:
            if j['error'].get('user_message') is not None:
                raise KinozalError(j['error']['user_message'], j['error']['code'])
            else:
                raise KinozalError(j['error']['message'], j['error']['code'])
        return j

    def catalog(self, section, limit, page='1'):
        url = self._base_url + 'api/video/'

        if isinstance(limit, basestring):
            limit = int(limit)

        if isinstance(page, basestring):
            page = int(page)

        category = []
        if section == 'films':
            category = ['world-film', 'our-film']
        elif section == 'multfilms':
            category = ['animation']
        elif section == 'serials':
            category = ['world-serial', 'owr-serial']
        elif section == 'multserials':
            category = ['animation-serial']
        elif section == 'tv-shows':
            category = ['tv-shows']

        params = {'action': 'video',
                  'sort_desc': 'added',
                  'season_last': '1',
                  'category[]': category,
                  'limit': limit,
                  'offset': limit * (page - 1),
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def video_info(self, content_id):
        url = self._base_url + 'api/video/'

        params = {'action': 'video',
                  'video_id': content_id,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        item_info = j['results'][0]

        return item_info

    def serial_info(self, content_id):
        url = self._base_url + 'api/video/'

        params = {'action': 'video',
                  'serial_id': content_id,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def video_link(self, content_id, episode=''):
        url = self._base_url + 'api/video/'

        episode = episode or ''

        params = {'action': 'link',
                  'video_id': content_id,
                  'episode': episode,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def search(self, query, limit, page='1'):

        url = self._base_url + 'api/video/'

        if isinstance(limit, basestring):
            limit = int(limit)

        if isinstance(page, basestring):
            page = int(page)

        params = {'action': 'video',
                  'q': query,
                  'limit': limit,
                  'offset': limit * (page - 1),
                  'season_last': '1',
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j
