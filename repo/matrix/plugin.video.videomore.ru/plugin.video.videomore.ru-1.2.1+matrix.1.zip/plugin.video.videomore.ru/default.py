# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import xbmc
import xbmcgui
import xbmcplugin

import simplemedia
import inputstreamhelper

from videomore import VideoMore
from simplemedia import py2_decode

# Create plugin instance
plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

use_subtitles = plugin.get_setting('use_subtitles')

def _show_api_error(err):
    plugin.log_error(err)
    try:
        text = _(str(err))
    except simplemedia.SimplePluginError:
        text = str(err)

    xbmcgui.Dialog().notification(plugin.addon.getAddonInfo('name'), text, xbmcgui.NOTIFICATION_ERROR)

def _show_notification(text):
    xbmcgui.Dialog().notification(plugin.addon.getAddonInfo('name'), text)

def _categories():

    categories = {'popular': {'title': _('Popular'), 'id': '0'},
                  'shows': {'title': _('Shows'), 'id': '1'},
                  'serials': {'title': _('Series'), 'id': '2'},
                  'programs': {'title': _('Programs'), 'id': '3'},
                  'films': {'title': _('Movies'), 'id': '4'},
                  'cartoons': {'title': _('Cartoons'), 'id': '5'},
                  }

    return categories

@plugin.route('/')
def root():
    if plugin.params.action is not None:
        if plugin.params.action == 'search':
            search()
    else:
        plugin.create_directory(_list_root())

def _list_root():

    categories = _categories()
    for name in ['serials', 'films', 'cartoons', 'programs']:
        category = categories[name]
        url = plugin.url_for('projects', category=name)
        list_item = {'label': category['title'],
                     'url': url,
                     'icon': plugin.icon,
                     'fanart': plugin.fanart,
                     'content_lookup': False,
                     }
        yield list_item

    url = plugin.url_for('search_history')
    list_item = {'label': _('Search'),
                 'url': url,
                 'icon': _get_image('DefaultAddonsSearch.png'),
                 'fanart': plugin.fanart,
                 'content_lookup': False,
                 }
    yield list_item

@plugin.route('/projects/<category>/')
def projects(category):
    category_info = _categories()[category]
    params = {'category_id': category_info['id'],
              'page': plugin.params.page or 1,
              'per_page': plugin.params.per_page or plugin.get_setting('per_page'),
              }
    if plugin.params.channel is not None:
        params['channel'] = plugin.params.channel


    if plugin.params.update_listing is not None:
        update_listing = plugin.params.update_listing == 'True'
        del plugin.params['update_listing']
    else:
        update_listing = (int(params['page']) > 1)

    try:
        if plugin.params.genre is not None:
            projects_info = _api.projects_by_genres(category_info['id'], plugin.params.genre)
        else:
            projects_info = _api.projects(params)

        plugin.create_directory(_list_projects(projects_info, category), 'tvshows', update_listing=update_listing, category=category_info['title'])
    except _api.ApiException as e:
        _show_api_error(e)
        plugin.create_directory([], succeeded=False)

def _list_projects(data, category=None):

    if category is not None:
        genre_value = plugin.params.genre or ''
        channel_value = plugin.params.channel or ''
        filters = _get_filters(category)
        if channel_value == '':
            yield _make_filter_item('genre', genre_value, filters['genre'], category)
        if genre_value == '':
            yield _make_filter_item('channel', channel_value, filters['channel'], category)

    use_pages = category is not None \
               and not plugin.params.genre
    
    use_atl_names = _use_atl_names()
    

    for project in data['list']:
        properties = {}

        if str(project['category_id']) in ['4','5'] \
          and project['count_episodes'] == 1:
            atl_params = {}
            if use_atl_names:
                atl_params['strm'] = 1

            mediatype = 'movie'
            url = plugin.url_for('play_project', project_id=project['id'], **atl_params)
            is_folder = False
            is_playable = True

            if use_atl_names \
              and project['year']:
                label = u'{0} ({1})'.format(project['title'], project['year'])
            else:
                label = project['title']
            
        else:
            mediatype = 'tvshow'
            url = plugin.url_for('project_seasons', project_id=project['id'])
            is_folder = True
            is_playable = False
            properties = {'TotalSeasons': str(project['count_season']),
                          'TotalEpisodes': str(project['overall_episodes']),
                          'WatchedEpisodes': '0',
                          }
            label = project['title']
 
        plugin.log_debug(url)
        
        country = project.get('country', [])
        if project.get('min_age') is not None:
            mpaa = _api.get_age_restricted_rating(project['min_age'], 'rars')
        else:
            mpaa = ''

        list_item = {'label': label,
                     'info': {'video': {'country': country,
                                        'genre': project['genre'],
                                        'year': project['year'],
                                        'title': label,
                                        'originaltitle': project['title'],
                                        'sorttitle': project['title'],
                                        'plot': project['description'],
                                        'mpaa': mpaa,
                                        'director': project['director'],
                                        'mediatype': mediatype,
                                        'dateadded': project['updated'][0:19].replace('T', ' '),
                                        }
                              },
                     'art': {'poster': project['poster'],
                             'banner': project.get('banner', ''),
                             },
                     'fanart': project.get('fanart', ''),
                     'thumb':  project['poster'],
                     'content_lookup': False,
                     'is_folder': is_folder,
                     'is_playable': is_playable,
                     'url': url,
                     'properties': properties,
                     }
        yield list_item

    page_params = {}
    page_params.update(plugin.params)

    if use_pages \
      and int(data['page']) > 1:
        prev_page = int(data['page']) - 1
        if prev_page == 1:
            del page_params['page']
        else:
            page_params['page'] = prev_page

        url = plugin.url_for('projects', category=category, **page_params)
        item_info = {'label': _('Previous page...'),
                     'url':   url}
        yield item_info

    if use_pages \
      and data['count'] == data['per_page']:
        page_params['page'] = int(data['page']) + 1
        url = plugin.url_for('projects', category=category, **page_params)
        item_info = {'label': _('Next page...'),
                     'url':   url}
        yield item_info

@plugin.route('/select_filter/<category>/<filter_id>/')
def select_filter( category, filter_id ):
    filter_title = _get_filter_title(filter_id)
    values_list = _get_filters(category)[filter_id]

    titles = []
    for list_item in values_list:
        titles.append(list_item['title'])

    ret = xbmcgui.Dialog().select(filter_title, titles)
    if ret >= 0:
        filter_value = values_list[ret]['id']

        plugin.params[filter_id] = filter_value
        cl_params = ['page', 'per_page']
        for cl_param in cl_params:
            if plugin.params.get(cl_param) is not None:
                del plugin.params[cl_param]

        url = plugin.url_for('projects', category=category, update_listing=True, **plugin.params)
        xbmc.executebuiltin('Container.Update("%s")' % url)

def _get_filter_title(filter_id):
    result = ''
    if filter_id == 'genre': result = _('Genre')
    elif filter_id == 'channel': result = _('Channel')

    return result

def _get_filter_icon(filter_id):
    image = ''
    if filter_id == 'genre': image = _get_image('DefaultGenre.png')

    if not image:
        image = plugin.icon

    return image

#@plugin.mem_cached(180)
def _make_filter_item( filter_id, filter_value, items, category ):

    filter_title = _get_filter_title(filter_id)
    url = plugin.url_for('select_filter', filter_id = filter_id, category=category, **plugin.params)
    label = _make_filter_label('yellowgreen', filter_title, _get_filter_name(items, filter_value))
    list_item = {'label': label,
                 'is_folder':   False,
                 'is_playable': False,
                 'url': url,
                 'icon': _get_filter_icon(filter_id),
                 'fanart': plugin.fanart}

    return list_item

def _get_filters(category):
    category_info = _categories()[category]
    genre = [{'title': _('All'), 'id': ''}]
    try:
        genre.extend(_get_partner_genres(category_info['id']))
    except _api.ApiException as e:
        _show_api_error(e)

    channel = [{'title': _('All'), 'id': ''}]
    try:
        channel.extend(_get_channels(category_info['id']))
    except _api.ApiException as e:
        _show_api_error(e)

    return {'genre': genre,
            'channel': channel,
            }

def _make_filter_label( color, title, category ):
    return '[COLOR={0}][B]{1}:[/B] {2}[/COLOR]'.format(color, title, category)

def _get_filter_name( items, value ):
    for item in items:
        if str(item['id']) == str(value):
            return item['title']

@plugin.mem_cached(180)
def _get_partner_genres(category_id):
    genres = _api.partner_genres(category_id)
    items = []
    for genre in genres:
        items.append(genre)
    return items

@plugin.mem_cached(180)
def _get_channels(category_id):
    channels = _api.allchannels()
    items = []
    for channel in channels:
        params = {'category_id': category_id,
                  'page': 1,
                  'per_page': 1,
                  'channel': channel['id'],
                  }
        try:
            projects_info = _api.projects(params)
            if projects_info['count'] > 0:
                items.append(channel)
        except _api.ApiException:
            pass
    return items

@plugin.route('/seasons/<project_id>/')
def project_seasons(project_id):

    try:
        seasons_info = _api.project_seasons(project_id)
        plugin.create_directory(_list_project_seasons(seasons_info), content='seasons', category=seasons_info['project']['title'],
                                sort_methods=[xbmcplugin.SORT_METHOD_TITLE])
    except _api.ApiException as e:
        _show_api_error(e)
        plugin.create_directory([], succeeded=False)

def _list_project_seasons(data):
    mediatype = 'season'
    project = data['project']
    for season in data['list']:
        if season['published'] == 0:
            continue
        
        url_params = {'project_id': project['id'],
                      'season_id': season['id'],
                      }
        if plugin.get_setting('use_atl_names'):
            url_params['atl'] = True

        url = plugin.url_for('project_episodes', **url_params)

        list_item = {'label': season['title'],
                     'info': {'video': {#'date': date,
                                        #'country': country,
                                        #'year': year,
                                        'title': season['title'],
                                        'originaltitle': season['title'],
                                        'sorttitle': season['title'],
                                        'plot': project['description'],
                                        'mpaa': _api.get_age_restricted_rating(project['min_age'],'rars'),
                                        #'director': body.get('director', []),
                                        #'writer': body.get('writer', []),
                                        #'credits': body.get('credits', []),
                                        'mediatype': mediatype,
                                        }
                              },
                     'art': {'poster': project['poster'],
                             },
                     'fanart': project['fanart'],
                     'thumb':  project['thumbnail'],
                     'content_lookup': False,
                     'is_folder': True,
                     'url': url,
                     }
        yield list_item

@plugin.route('/episodes/<project_id>/<season_id>/')
def project_episodes(project_id, season_id):

    if _use_atl_names():
        sort_methods = [xbmcplugin.SORT_METHOD_DATEADDED]
    else:
        sort_methods = [xbmcplugin.SORT_METHOD_EPISODE]

    try:
        episodes_info = _api.project_episodes(project_id, season_id)
        plugin.create_directory(_list_episodes(episodes_info), content='episodes', category=episodes_info['project']['title'],
                         total_items=episodes_info['count'], sort_methods=sort_methods)
    except _api.ApiException as e:
        _show_api_error(e)
        plugin.create_directory([], succeeded=False)

def _list_episodes(data):

    atl_params = {}
    if _use_atl_names():
        atl_params['strm'] = 1

    mediatype = 'episode'
    for episode in data['list']:
        item = _get_item(episode, data['project'])

        item['url'] = plugin.url_for('play_track', track_id=episode['id'], **atl_params)
        yield item

def _get_item(episode, project, for_play=False):

    use_atl_names = _use_atl_names() \
                     and not for_play

    info_video = {'country': project['country'],
                  'year': project['year'],
                  'plot': episode['description'],
                  'mpaa': _api.get_age_restricted_rating(episode['min_age'], 'rars'),
                  'duration': episode['duration'],
                  'dateadded': episode['updated'][0:19].replace('T', ' '),
                  }

    if str(project['category_id']) in ['4','5'] \
      and project['count_episodes'] == 1:
        label = project['title']

        info_video.update({'title': label,
                           'originaltitle': project['title'],
                           'sorttitle': label,
                           'mediatype': 'movie',
                           })
    else:
        episode_title = _get_episode_title(episode['title'])
        if use_atl_names:
            label_parts = [episode['project_title'],
                           's%02de%02d' % (episode['season_pos'], episode['episode_of_season'])]
            if episode_title != episode['title']:
                label_parts.append(episode_title)
            label = '.'.join(label_parts)
        else:
            label = episode_title

        info_video.update({'season': episode['season_pos'],
                           'sortseason': episode['season_pos'],
                           'episode': episode['episode_of_season'],
                           'sortepisode': episode['episode_of_season'],
                           'title': label,
                           'originaltitle': label,
                           'sorttitle': label,
                           'tvshowtitle': episode['project_title'],
                           'mediatype': 'episode',
                           })

    list_item = {'label': episode['title'],
                 'info': {'video': info_video,
                          },
                 'art': {'poster': project['poster'],
                         'banner': project['banner'],
                         },
                 'fanart': project['fanart'],
                 'thumb':  episode['thumbnail'],
                 'content_lookup': False,
                 'is_folder': False,
                 'is_playable': True,
                 }

    return list_item

@plugin.route('/track/<track_id>/', 'play_track_old')
@plugin.route('/track/<track_id>')
def play_track(track_id):

    try:
        episode = _api.project_episode(track_id)
        project = _api.project(episode['project_id'])

        succeeded = True
    except _api.ApiException as e:
        _show_api_error(e)
        succeeded = False

    play_episode(project, episode, succeeded)

@plugin.route('/project/<project_id>/', 'play_project_old')
@plugin.route('/project/<project_id>')
def play_project(project_id):

    succeeded = False
    try:
        episodes_info = _api.project_episodes(project_id)
    except _api.ApiException as e:
        _show_api_error(e)

    project = episodes_info['project']
    for _episode in episodes_info['list']:
        episode = _episode
        succeeded = True

    play_episode(project, episode, succeeded)

def play_episode(project, episode, succeeded):
    list_item = {}

    if succeeded:

        is_strm = plugin.params.get('strm') == '1' \
                   and plugin.kodi_major_version() >= '18'
    
        if not is_strm:
            list_item = _get_item(episode, project, True)

        succeeded = False

        dialog = xbmcgui.Dialog()
        if not episode['geolocation_allow']:
            dialog.ok(plugin.name, _('This video not available in your region'))
        elif episode['paid'] \
            and episode['hls'][0:3] != 'http':
            dialog.ok(plugin.name, _('This video must be purchased'))
        elif episode['encrypted']:
            ia_helper = inputstreamhelper.Helper('mpd', drm='widevine')
            if ia_helper.check_inputstream():
                properties = {'inputstream.adaptive.license_type': 'com.widevine.alpha',
                              'inputstream.adaptive.license_key': 'http://widevine.videomore.ru/cenc/getlicense/inventosvideomore|Content-Type=application/octet-stream&User-Agent=ExoPlayer&Accept-Encoding=gzip&Connection=Keep-Alive|R{SSM}|',
                              'inputstream.adaptive.manifest_type': 'mpd',
                              'inputstreamaddon': 'inputstream.adaptive',
                              }
                list_item['mime'] = 'application/dash+xml'
                list_item['properties'] = properties
                list_item['path'] = episode['widevine_modular']
                succeeded = True
        else:
            list_item['path'] = _get_video_path(episode)
            succeeded = True


    plugin.resolve_url(list_item, succeeded)
    

@plugin.route('/search_history/')
def search_history():

    with plugin.get_storage('__history__.pcl') as storage:
        history = storage.get('history', [])

        if len(history) > plugin.get_setting('history_length'):
            history[plugin.history_length - len(history):] = []
            storage['history'] = history

    listing = []
    listing.append({'label': _('New Search...'),
                    'url': plugin.url_for('search'),
                    'icon': _get_image('DefaultAddonsSearch.png'),
                    'is_folder': False,
                    'is_playable': False,
                    'fanart': plugin.fanart})

    for item in history:
        listing.append({'label': item['keyword'],
                        'url': plugin.url_for('search', keyword=item['keyword']),
                        'icon': plugin.icon,
                        'is_folder': True,
                        'is_playable': False,
                        'fanart': plugin.fanart})

    plugin.create_directory(listing, content='files', category=_('Search'))

@plugin.route('/search')
def search():

    keyword  = plugin.params.keyword or ''
    usearch  = (plugin.params.usearch == 'True')

    new_search = (keyword == '')

    if not keyword:
        kbd = xbmc.Keyboard()
        kbd.setDefault('')
        kbd.setHeading(_('Search'))
        kbd.doModal()
        if kbd.isConfirmed():
            keyword = kbd.getText()

    if keyword and new_search and not usearch:
        with plugin.get_storage('__history__.pcl') as storage:
            history = storage.get('history', [])
            history.insert(0, {'keyword': keyword})
            if len(history) > plugin.get_setting('history_length'):
                history.pop(-1)
            storage['history'] = history


        url = plugin.url_for('search', keyword=py2_decode(keyword))
        xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword:
        projects_info = _api.search_projects(keyword)

        plugin.create_directory(_list_projects(projects_info), content='tvshows', category=_('Search'))

def _get_video_path(data):

    video_quality = plugin.get_setting('video_quality')

    path = ''
    if (not path or video_quality >= 0) and data['q3']:
        path = data['q3']
    if (not path or video_quality >= 1) and data['hls']:
        path = data['hls']

    return path
def _get_episode_title(episode_title):
    dot_pos = episode_title.find('.')
    if dot_pos >= 0 \
      and episode_title[dot_pos-5:dot_pos].lower() == 'серия':
        title = episode_title[dot_pos + 1:].strip()
    else:
        title = episode_title
    return title

def _get_image(image):
    return image if xbmc.skinHasImage(image) else plugin.icon

def _use_atl_names():
    return plugin.params.get('atl', '').lower() == 'true' \
             or plugin.get_setting('use_atl_names')

if __name__ == '__main__':
    _api = VideoMore('VMCVTAndr', '3edca6b209a969d5a56215d63a38f26a')
    plugin.run()