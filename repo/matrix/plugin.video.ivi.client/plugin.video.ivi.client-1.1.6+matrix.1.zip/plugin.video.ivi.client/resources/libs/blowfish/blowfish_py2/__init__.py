# -*- coding: utf-8 -*-

from .blowfish import Blowfish as bf


class Blowfish(bf):
    
    def __init__ (self, key):

        if isinstance(key, (bytes, bytearray)):
            key = str(key)
            
        super(Blowfish, self).__init__(key)

    def encryptCBC(self, data):

        if isinstance(data, (bytes, bytearray)):
            data = str(data)
            
        return super(Blowfish, self).encryptCBC(data)
        

__all__ = ['Blowfish']
