# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import os

import simplemedia
import xbmc

from .tvzavr import TVZavrError, TVZavrClient

addon = simplemedia.Addon()


class TVZavr(TVZavrClient):

    def __init__(self):

        if self._plf is None:
            plf = 'htm'
            plf_secret = 'c58ad145141cedc57523c6305b6df7960ca844371d325db23412abc8e884c114'

            super(TVZavr, self).__init__(plf, plf_secret)

            headers = self._client.headers
            if addon.kodi_major_version() >= '17':
                headers['User-Agent'] = xbmc.getUserAgent()

            cookie_file = os.path.join(addon.profile_dir, 'tvzavr.cookies')

            self._client = simplemedia.WebClient(headers, cookie_file)

    def check_device(self):
        dev_id = addon.get_setting('dev_id')
        customer_regkey = addon.get_setting('customer_regkey')
        if dev_id:
            try:
                self.user_dev_login(dev_id)
            except simplemedia.WebClientError:
                pass
            except TVZavrError as e:
                if e.status != 9:
                    addon.notify_error(e)
                elif customer_regkey != 'fakeuser':
                    user_fields = self.get_user_fields()
                    addon.set_settings(user_fields)

        default_uuid = addon.get_setting('default_uuid')
        customer_uuid = addon.get_setting('customer_uuid')
        try:
            if default_uuid == '':
                user_info = self.user_register()
                dev_id = self.user_login(user_id=user_info['customer__uuid'])
            elif customer_uuid == '':
                dev_id = self.user_login(user_id=default_uuid)
                user_info = self.user_get_info()
            else:
                user_info = self.user_get_info()

        except (TVZavrError, simplemedia.WebClientError):
            pass
        else:
            user_fields = self.get_user_fields(user_info)
            addon.set_settings(user_fields)

            if not default_uuid:
                addon.set_setting('default_uuid', user_fields['customer_uuid'])

            addon.set_setting('dev_id', dev_id)

    def clip_position(self, clip_id, ctx):
        try:
            progress = self.user_progress(clip_id, ctx)
        except (TVZavrError, simplemedia.WebClientError) as e:
            if isinstance(e, TVZavrError) \
                    and e.status == 4:
                return 0
            else:
                raise e
        else:
            return progress['position']

    @staticmethod
    def get_user_fields(user_info=None):
        user_info = user_info or {}

        customer_gender = user_info.get('customer__gender') or ''
        if customer_gender == 'female':
            customer_gender_id = 1
        else:
            customer_gender_id = 0

        customer_regkey = user_info.get('customer__regkey') or 'fakeuser'
        if customer_regkey == 'fakeuser':
            customer_store_progress = False
        else:
            customer_store_progress = user_info.get('customer__store_progress') or False

        fields = {'customer_name': user_info.get('customer__name') or '',
                  'customer_nickname': user_info.get('customer__nickname') or '',
                  'customer_gender': customer_gender_id,
                  'customer_birthday': user_info.get('customer__birthday') or '',
                  'customer_regkey': customer_regkey,
                  'customer_uuid': user_info.get('customer__uuid') or '',
                  'customer_uid': user_info.get('customer__uid') or '',
                  'customer_store_progress': customer_store_progress,
                  }

        return fields


class VideoInfo(simplemedia.VideoInfo):
    plugin = None

    _path = None
    _trailer = None
    _playcount = None
    _userrating = None

    def __init__(self, data, for_play=False, atl_names=False):
        self._data = data

        self._for_play = for_play
        self._atl_names = atl_names and not for_play

    @property
    def genre(self):
        genres = self._data.get('genres')
        if genres is not None:
            return [genre['mark__name'] for genre in genres]

    @property
    def country(self):
        countries = self._data.get('countries')
        if countries is not None:
            return [country['mark__name'] for country in countries]

    @property
    def year(self):
        years = self._data.get('years')
        if years is not None:
            return int(years[0]['mark__name'])

    @property
    def episode(self):
        if self.mediatype == 'episode':
            return self._data['clip__position']

    @property
    def season(self):
        if self.mediatype == 'season':
            return self._data['clip__position']
        elif self.mediatype == 'episode':
            return self._data['clip__season_number'] or 1

    @property
    def userrating(self):
        return self._userrating

    @property
    def playcount(self):
        return self._playcount

    @property
    def cast(self):
        actors = self._data.get('actors')
        if actors is not None:
            return [actor['mark__name'] for actor in actors]

    @property
    def director(self):
        directors = self._data.get('directors')
        if directors is not None:
            return [director['mark__name'] for director in directors]

    @property
    def mpaa(self):
        age_limit = self._data.get('age_limit')
        if age_limit is not None \
                and isinstance(age_limit, int):
            return '{0}+'.format(age_limit)

    @property
    def plot(self):
        description = self._data['clip__description']
        if self.plugin is not None:
            description = self.plugin.remove_html(description)

        return description

    @property
    def title(self):

        if self._atl_names:
            title = self.__atl_title()
        else:
            title = self.__title()

        if not self._for_play:
            title_postfix = self.__title_postfix()
            if title_postfix:
                title = title + title_postfix

        return title

    @property
    def original_title(self):
        if self.mediatype in ['movie', 'tvshow']:
            if self._data['clip__special_name']:
                return self._data['clip__special_name']

        return self.__title()

    @property
    def duration(self):
        if self.mediatype in ['movie', 'episode']:
            return self._data['clip__duration'] * 60

    @property
    def tvshowtitle(self):
        if self.mediatype in ['season', 'episode']:
            return self._data['clip__set_name']
        elif self.mediatype == 'tvshow':
            return self._data['clip__name']

    @property
    def tag(self):
        tags = self._data.get('tags')
        if tags is not None:
            return [tag['mark__name'] for tag in tags]

    @property
    def imdbnumber(self):
        return self._data.get('clip__imdb_id')

    @property
    def dateadded(self):
        return self._data.get('clip__date', '')

    @property
    def path(self):
        return self._path

    @property
    def trailer(self):
        if self.mediatype in ['movie', 'tvshow']:
            return self._trailer

    @property
    def mediatype(self):
        mediatype_ = getattr(self, '_mediatype', None)
        if mediatype_ is None:
            type_id = self._data['clip__type_id']
            if type_id == 1:
                mediatype_ = 'movie'
            elif type_id == 2:
                mediatype_ = 'tvshow'
            elif type_id == 3:
                mediatype_ = 'episode'
            elif type_id == 5:
                mediatype_ = 'season'
            self._mediatype = mediatype_

        return self._mediatype

    def __title(self):

        if self.mediatype == 'season':
            title = self._data['season__name']
        elif self.mediatype == 'episode' \
                and self._data['clip__name'] == '':
            title = '{0} {1}'.format(self.plugin.gettext('Episode'), self.episode)
        else:
            title = self._data['clip__name']

        return title

    def __title_postfix(self):

        purchase_info = self._data.get('purchase_info')

        if self._data['requires_subscription'] == 'Yes' \
                and not isinstance(purchase_info, dict):
            tariffs_items = []

            tariffs_list = self._data.get('tariffs') or []
            for tariff in tariffs_list:
                if tariff['type_alias'] not in tariffs_items:
                    tariffs_items.append(tariff['type_alias'])

            postfix_parts = []
            if 'purchase' in tariffs_items:
                postfix_parts.append(self.plugin.gettext('Purchase'))
            if 'subscription' in tariffs_items:
                postfix_parts.append(self.plugin.gettext('Subscription'))

            if postfix_parts:
                return ' [{0}]'.format('/'.join(postfix_parts))

        return ''

    def __atl_title(self):

        title_parts = []
        if self.mediatype == 'movie':
            title_parts.append(self.original_title)
            if self.year is not None:
                title_parts.append('({0})'.format(self.year))

        elif self.mediatype == 'episode':
            title_parts.append(self.tvshowtitle)
            title_parts.append('s%02de%02d' % (self.season, self.episode))
            if self._data['clip__name'] != '':
                title_parts.append(self._data['clip__name'])

        else:
            title_parts.append(self.__title())

        return ' '.join(title_parts)

    def has_trailer(self):
        return self._data['clip__trailer_url'] != ''

    def set_trailer(self, trailer):
        self._trailer = trailer

    def set_path(self, path):
        self._path = path

    def set_playcount(self, playcount):
        self._playcount = playcount

    def set_userrating(self, userrating):
        self._userrating = userrating


class EmptyListItem(simplemedia.ListItemInfo):
    _url = None
    _path = None
    _video_info = None

    @property
    def path(self):
        return self._path

    @property
    def url(self):
        return self._url

    def set_url(self, url):
        self._url = url
        self.set_path(url)

    def set_path(self, path):
        self._path = path

        if isinstance(self._video_info, VideoInfo):
            self._video_info.set_path(path)


class ListItem(EmptyListItem):
    plugin = None

    position = 0
    _img_url = 'http://cdn.tvzavr.ru/common/tvzstatic/cache'

    def __init__(self, video_info, default_rating, category=None):

        self._video_info = video_info
        self._category = category

        self._data = video_info._data
        self._mediatype = video_info.mediatype
        self._for_play = video_info._for_play

        self._default_rating = default_rating

        self.clip_id = self.__clip_id()
        self.parent_id = self.__parent_id()
        self.season_id = self.__season_id()

        if video_info.has_trailer() \
                and self.plugin is not None:
            trailer_path = self.plugin.url_for('play_trailer', clip_id=self.clip_id)
            video_info.set_trailer(trailer_path)

        if addon.get_setting('customer_store_progress'):
            api = TVZavr()
            if self._mediatype in ['movie', 'episode']:
                ctx = self._data['clip_types__type'].lower()

                try:
                    self.position = api.clip_position(self.clip_id, ctx)
                except (TVZavrError, simplemedia.WebClientError) as e:
                    addon.notify_error(e)
                    self.position = 0

            try:
                video_personal = api.video_video_personal(self.clip_id)
            except (TVZavrError, simplemedia.WebClientError) as e:
                addon.notify_error(e)
            else:
                if self._mediatype in ['movie', 'episode'] \
                        and self.position <= 0 \
                        and video_personal['seen']:
                    self._video_info.set_playcount(1)
                self._video_info.set_userrating(video_personal['myrate'] * 2)

    @property
    def label(self):
        return self._video_info.title

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        return self._mediatype in ['movie', 'episode']

    @property
    def context_menu(self):
        context_menu = []

        favorite = self._data.get('favorite')
        if favorite is not None \
                and self.plugin is not None:
            if favorite:
                title = self.plugin.gettext('Remove from \'Favorites\'')
                url = self.plugin.url_for('favorites_rem', clip_id=self.parent_id)
            else:
                title = self.plugin.gettext('Add to \'Favorites\'')
                url = self.plugin.url_for('favorites_add', clip_id=self.parent_id)

            context_menu.append((title, 'RunPlugin({0})'.format(url)))

        if self._category == 'favorites':
            title = self.plugin.gettext('Clear \'Favorites\'')
            url = self.plugin.url_for('favorites_rem_all')
            context_menu.append((title, 'RunPlugin({0})'.format(url)))

        elif self._category == 'viewed':
            title = self.plugin.gettext('Remove from \'Viewed\'')
            url = self.plugin.url_for('history_rem', clip_id=self.parent_id)
            context_menu.append((title, 'RunPlugin({0})'.format(url)))

            title = self.plugin.gettext('Clear \'Viewed\'')
            url = self.plugin.url_for('history_rem_all')
            context_menu.append((title, 'RunPlugin({0})'.format(url)))

        return context_menu

    @property
    def properties(self):
        properties = {}

        if self.position > 0:
            properties['TotalTime'] = '{0}'.format(self._video_info.duration)
            properties['ResumeTime'] = '{0}'.format(self.position)

        return properties

    @property
    def online_db_ids(self):
        db_ids = {'tvzavr': str(self.clip_id)}

        if self._data.get('clip__kp_id') is not None:
            db_ids['kinopoisk'] = str(self._data['clip__kp_id'])
        if self._data.get('clip__imdb_id') is not None:
            db_ids['imdb'] = self._data['clip__imdb_id']

        return db_ids

    @property
    def ratings(self):
        tvz_votes = self._data['clip__rates']
        tvz_ratesum = float(self._data['clip__ratesum']) * 2
        tvz_rating = 0 if tvz_votes == 0 else tvz_ratesum / tvz_votes

        ratings = [self._make_rating('kinopoisk', self._data['clip__kp_rate']),
                   self._make_rating('imdb', self._data['clip__imdb_rate']),
                   self._make_rating('tvzavr', tvz_rating, tvz_votes),
                   ]

        for rating in ratings:
            rating['defaultt'] = (rating['type'] == self._default_rating)

        return ratings

    @staticmethod
    def _make_rating(type_, rating, votes=0):
        if rating:
            rating = round(rating, 2)
        else:
            rating = 0

        return {'type': type_,
                'rating': rating,
                'votes': votes,
                'defaultt': False,
                }

    @property
    def art(self):
        art = {}
        if self._mediatype in ['tvshow', 'movie']:
            art['poster'] = self.poster()
        elif self._mediatype in ['season', 'episode']:
            art['tvshow.poster'] = self.poster()

        return art

    def poster(self):
        return self._img_url + '/500x750/{0}.jpg'.format(self.clip_id)

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self.poster()
        elif self._mediatype == 'episode':
            return self._img_url + '/644x363/{0}.jpg'.format(self.clip_id)

    @property
    def fanart(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self._img_url + '/644x363/{0}.jpg'.format(self.clip_id)
        elif self._mediatype == 'episode':
            return self._img_url + '/644x363/{0}.jpg'.format(self._data['clip__parent_node_id'])

    @property
    def stream_info(self):
        if self._mediatype == 'movie':
            return {'video': self.__video_stream_info()}

    @property
    def info(self):
        return {'video': self._video_info.get_info()}

    @property
    def season(self):
        if self._mediatype in ['season', 'episode']:
            return {'number': self._video_info.season}

    def __clip_id(self):
        if self._mediatype in ['movie', 'tvshow', 'episode']:
            return self._data['clip__id']
        elif self._mediatype in ['season']:
            if self._data['season__id'] is not None:
                return self._data['clip__parent_node_id']
            else:
                return self._data['clip__id']

    def __season_id(self):
        if self._mediatype in ['season']:
            return self._data['season__id']

    def __parent_id(self):
        if self._mediatype == 'season' \
                and self._data.get('season__id') is not None:
            return self._data['clip__parent_node_id']
        elif self._mediatype == 'episode' \
                and self._data.get('clip__parent_node_id') is not None:
            return self._data['clip__parent_node_id']
        else:
            return self._data['clip__id']

    def __video_stream_info(self):

        qualities = []
        for quality in self._data['quality']:
            qualities.append(quality['quality__alias'])

        if '4k' in qualities:
            stream_info = {'width': 3840,
                           'height': 2160,
                           }
        elif 'fhd' in qualities:
            stream_info = {'width': 1920,
                           'height': 1080,
                           }
        elif 'hd' in qualities:
            stream_info = {'width': 1280,
                           'height': 720,
                           }
        else:
            stream_info = {'width': 720,
                           'height': 416,
                           }

        return stream_info
