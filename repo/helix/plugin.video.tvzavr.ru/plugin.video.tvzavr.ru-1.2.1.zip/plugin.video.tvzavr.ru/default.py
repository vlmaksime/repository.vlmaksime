# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import platform

import simplemedia
import xbmc
import xbmcgui
import xbmcplugin
from resources.libs import TVZavr, TVZavrError, VideoInfo, EmptyListItem, ListItem

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

VideoInfo.plugin = plugin
ListItem.plugin = plugin


@plugin.route('/login')
def login():
    _login = plugin.get_keyboard_text('', _('Enter your e-mail'))
    if _login:

        xbmc.sleep(1000)

        _password = plugin.get_keyboard_text('', _('Enter your password'), True)
        if _password:
            try:
                api = TVZavr()
                dev_id = api.user_login(_login, _password, dev_description=_get_device())
                user_info = api.user_get_info()
            except (TVZavrError, simplemedia.WebClientError) as e:
                plugin.notify_error(e, True)
            else:
                user_fields = api.get_user_fields(user_info)
                plugin.set_settings(user_fields)
                plugin.set_setting('dev_id', dev_id)

                if user_fields['customer_regkey'] != 'fakeuser':
                    plugin.dialog_ok(_('You have successfully logged in'))
                else:
                    plugin.dialog_ok(_('Incorrect login or password!'))


@plugin.route('/auth_id')
def auth_id():
    try:
        api = TVZavr()
        get_result = api.user_get_auth_id(_get_device())
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
    else:
        dev_id = get_result['dev_id']

        progress = xbmcgui.DialogProgress()
        progress.create(_('Sign in by device code'),
                        _('Device code: [B]{0}[/B]').format(get_result['auth_id']),
                        _('Enter this code on the page [B]tvzavr.ru/link[/B]'),
                        _('or in the mobile application in the section [B]\'Profile\' - \'Add device\'[/B]'))

        wait_sec = 180
        step_sec = 2
        pass_sec = 0
        check_sec = 10

        check_result = 'wait'

        while pass_sec < wait_sec \
                and check_result == 'wait':
            if progress.iscanceled():
                check_result = 'canceled'
            else:
                xbmc.sleep(step_sec * 1000)
                pass_sec += step_sec

                progress_value = int(100 * pass_sec / wait_sec)
                progress.update(progress_value)

                if (pass_sec % check_sec) == 0:
                    try:
                        check_result = api.user_check_auth_id(dev_id)
                    except (TVZavrError, simplemedia.WebClientError) as e:
                        plugin.notify_error(e, True)
                        check_result = 'error'

        progress.close()

        if check_result != 'success':
            plugin.dialog_ok(_('Device not connected'))
        else:
            try:
                api.user_dev_login(dev_id)
                user_info = api.user_get_info()
            except (TVZavrError, simplemedia.WebClientError) as e:
                plugin.notify_error(e, True)
            else:
                user_fields = api.get_user_fields(user_info)
                plugin.set_settings(user_fields)
                plugin.set_setting('dev_id', dev_id)

                if user_fields['customer_nickname']:
                    plugin.dialog_ok(_('Device successfully connected'))


@plugin.route('/logout')
def logout():
    dev_id = plugin.get_setting('dev_id')
    default_uuid = plugin.get_setting('default_uuid')
    try:
        api = TVZavr()
        api.user_logout(dev_id)
        dev_id = api.user_login(user_id=default_uuid)
        user_info = api.user_get_info()
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
    else:
        user_fields = api.get_user_fields(user_info)
        plugin.set_settings(user_fields)
        plugin.set_setting('dev_id', dev_id)

        plugin.dialog_ok(_('You have successfully logged out'))


@plugin.route('/')
def root():
    plugin.create_directory(_root_list(), content='', category=plugin.name)


def _root_list():
    # Catalog
    for catalog_item in _catalog_items():
        url = plugin.url_for('catalog', cats=catalog_item['category'])
        listitem = {'label': catalog_item['title'],
                    'url': url,
                    'icon': catalog_item['icon'],
                    'fanart': plugin.fanart,
                    'content_lookup': False,
                    }
        yield listitem

    # Collections
    url = plugin.url_for('catalog_groups')
    listitem = {'label': _('Collections'),
                'url': url,
                'icon': plugin.get_image('DefaultFavourites.png'),
                'fanart': plugin.fanart,
                'content_lookup': False,
                }
    yield listitem

    customer_regkey = plugin.get_setting('customer_regkey')

    for catalog_item in _catalog_history_items():

        if catalog_item['category'] == 'purchased' \
                and customer_regkey == 'fakeuser':
            continue

        url = plugin.url_for('catalog_history', cat_type=catalog_item['category'])
        listitem = {'label': catalog_item['title'],
                    'url': url,
                    'icon': catalog_item['icon'],
                    'fanart': plugin.fanart,
                    'content_lookup': False,
                    }
        yield listitem

    # Search
    url = plugin.url_for('search_history')
    listitem = {'label': _('Search'),
                'url': url,
                'icon': plugin.get_image('DefaultAddonsSearch.png'),
                'fanart': plugin.fanart,
                'content_lookup': False,
                }
    yield listitem


@plugin.route('/catalog/', 'catalog_ctx')
@plugin.route('/catalog/<cats>/')
def catalog(cats=None):
    offset = plugin.params.offset or '0'
    offset = int(offset)

    limit = plugin.params.limit
    if not limit:
        limit = plugin.get_setting('limit', False)
    limit = int(limit)

    client_ctx = plugin.params.client_ctx
    sort = plugin.params.sort

    try:
        api = TVZavr()
        catalog_result = api.catalog(cats, client_ctx, offset, limit, sort)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:

        if cats is not None:
            page_params = {'cats': cats,
                           }
            action = 'catalog'
        else:
            page_params = {}
            action = 'catalog_ctx'

            catalog_info = _catalog_info(cats, client_ctx)
            list_limit = min(limit, catalog_info['counter'] - offset)
            catalog_result = {'total_count': catalog_info['counter'],
                              'video_list': catalog_result['video_list'][:list_limit],
                              }

        if sort is not None:
            page_params['sort'] = sort

        if client_ctx is not None:
            page_params['client_ctx'] = client_ctx

        _list_catalog(action, offset, limit, catalog_result, page_params, cats, client_ctx)


@plugin.route('/catalog/history/<cat_type>/')
def catalog_history(cat_type):
    offset = plugin.params.offset or '0'
    offset = int(offset)

    limit = plugin.params.limit
    if not limit:
        limit = plugin.get_setting('limit', False)
    limit = int(limit)

    sort = plugin.params.sort

    try:
        api = TVZavr()
        catalog_result = api.catalog_history(cat_type, offset, limit, sort)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
        return

    page_params = {'cat_type': cat_type,
                   }

    if sort is not None:
        page_params['sort'] = sort

    _list_catalog('catalog_history', offset, limit, catalog_result, page_params, cat_type)


@plugin.route('/search/history/')
def search_history():
    result = {'items': plugin.search_history_items(),
              'content': '',
              'category': ' / '.join([plugin.name, _('Search')]),
              }

    plugin.create_directory(**result)


@plugin.route('/catalog/groups/')
def catalog_groups():
    result = {'items': _catalog_groups_list(),
              'content': '',
              'category': ' | '.join([plugin.name, _('Collections')]),
              'sort_methods': xbmcplugin.SORT_METHOD_NONE,
              }
    plugin.create_directory(**result)


def _catalog_groups_list():
    for catalog_item in _catalog_group_items():
        if catalog_item['counter'] > 0:
            url = plugin.url_for('catalog_ctx', client_ctx=catalog_item['client_ctx'])
            listitem = {'label': catalog_item['title'],
                        'url': url,
                        'icon': catalog_item['icon'],
                        'fanart': plugin.fanart,
                        'content_lookup': False,
                        }
            yield listitem


@plugin.route('/search/remove/<int:index>')
def search_remove(index):
    plugin.search_history_remove(index)


@plugin.route('/search/clear')
def search_clear():
    plugin.search_history_clear()


@plugin.route('/search')
def search():
    keyword = plugin.params.keyword or ''
    usearch = plugin.params.usearch or ''
    is_usearch = (usearch.lower() == 'true')

    if not keyword:
        keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
                and not is_usearch:
            plugin.update_search_history(keyword)

            url = plugin.url_for('search', keyword=keyword)
            xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword is not None:
        try:
            api = TVZavr()
            search_result = api.search_split(keyword)
        except (TVZavrError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.create_directory([], succeeded=False)
        else:
            search_items = []
            for group_list in search_result['search_group_list']:
                search_items.extend(group_list['video_list'])

            result = {'items': _listitems(search_items),
                      'total_items': len(search_items),
                      'content': 'movies',
                      'category': ' / '.join([_('Search'), keyword]),
                      'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
                      }
            plugin.create_directory(**result)


def _list_catalog(action, offset, limit, catalog_result, page_params, category=None, client_ctx=None):
    catalog_info = _catalog_info(category, client_ctx)

    pages = _get_pages(page_params, offset, limit, catalog_result['total_count'], action)

    category_parts = [catalog_info['title'],
                      '{0} {1}'.format(_('Page'), int(offset / limit) + 1),
                      ]

    catalog_items = catalog_result['video_list']

    result = {'items': _listitems(catalog_items, pages, category, client_ctx),
              'total_items': len(catalog_items),
              'content': catalog_info['content'],
              'category': ' / '.join(category_parts),
              'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
              'update_listing': (offset > 0),
              }
    plugin.create_directory(**result)


@plugin.route('/series/<clip_id>/seasons/')
def seasons(clip_id):
    try:
        api = TVZavr()
        tvshow_result = api.video_get_info(clip_id)
        seasons_result = api.video_get_seasons(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:
        tvshow_info = VideoInfo(tvshow_result)
        _category = tvshow_info.title

        seasons_items = seasons_result['seasons']
        total_items = len(seasons_items)
        if seasons_result['total_count'] > total_items:
            try:
                seasons_result = api.video_get_seasons(clip_id, total_items, seasons_result['total_count'])
            except (TVZavrError, simplemedia.WebClientError) as e:
                plugin.notify_error(e)
            else:
                seasons_items.extend(seasons_result['seasons'])
                total_items = len(seasons_items)

        del seasons_result

        category_parts = [_category]

        if not seasons_items:
            fake_season = tvshow_result
            fake_season['season__name'] = '{0} 1'.format(_('Season'))
            fake_season['season__id'] = None
            fake_season['clip__position'] = 1
            fake_season['clip__type_id'] = 5

            seasons_items.append(fake_season)

        result = {'items': _listitems(seasons_items),
                  'total_items': total_items,
                  'content': 'seasons',
                  'category': ' / '.join(category_parts),
                  'sort_methods': xbmcplugin.SORT_METHOD_LABEL,
                  }
        plugin.create_directory(**result)


@plugin.route('/series/<clip_id>/episodes/', 'episodes_without_season')
@plugin.route('/series/<clip_id>/seasons/<season_id>/episodes/')
def episodes(clip_id, season_id=None):
    use_atl_names = _use_atl_names()

    try:
        api = TVZavr()
        tvshow_result = api.video_get_info(clip_id)
        if season_id is None:
            episodes_result = api.video_get_childs(clip_id)
        else:
            episodes_result = api.video_get_series(season_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        plugin.create_directory([], succeeded=False)
    else:
        tvshow_info = VideoInfo(tvshow_result)
        del tvshow_result

        _category = tvshow_info.title

        episodes_items = episodes_result['series']
        total_items = len(episodes_items)
        if episodes_result['total_count'] > total_items:
            try:
                if season_id is None:
                    episodes_result = api.video_get_childs(clip_id, total_items, episodes_result['total_count'])
                else:
                    episodes_result = api.video_get_series(season_id, total_items, episodes_result['total_count'])
            except (TVZavrError, simplemedia.WebClientError) as e:
                plugin.notify_error(e)
            else:
                episodes_items.extend(episodes_result['series'])
                total_items = len(episodes_items)

        del episodes_result

        category_parts = [_category]

        if use_atl_names:
            sort_methods = xbmcplugin.SORT_METHOD_NONE
        else:
            sort_methods = xbmcplugin.SORT_METHOD_EPISODE

        result = {'items': _listitems(episodes_items),
                  'total_items': total_items,
                  'content': 'episodes',
                  'category': ' / '.join(category_parts),
                  'sort_methods': sort_methods,
                  }
        plugin.create_directory(**result)


@plugin.route('/video/<clip_id>/play', 'play_old')
@plugin.route('/video/<clip_id>/play/')
def play_video(clip_id):
    is_strm = plugin.params.strm == '1' \
              and plugin.kodi_major_version() >= '18'

    try:
        api = TVZavr()
        video_result = api.video_get_info(clip_id)
        url_info = api.video_url(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
        succeeded = False
        listitem = EmptyListItem()
        data = {}
    else:
        succeeded = True

        video_info = VideoInfo(video_result, True)

        default_rating = _get_rating_source()
        listitem = ListItem(video_info, default_rating)

        data = {'clip_id': listitem.clip_id,
                'parent_id': listitem.parent_id,
                'ctx': listitem._data['clip_types__type'].lower(),
                'title': video_info.title,
                }

        url = plugin.url_for('play_video', clip_id=listitem.clip_id)
        listitem.set_url(url)

        playlist_url = _get_playlist_url(url_info)
        if playlist_url is None:
            succeeded = False
        else:
            listitem.set_path(playlist_url)

    if is_strm:
        listitem.__class__ = EmptyListItem

    if succeeded:
        plugin.send_notification('OnPlay', data)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/video/<clip_id>/trailer/')
def play_trailer(clip_id):
    succeeded = True

    listitem = EmptyListItem()

    try:
        api = TVZavr()
        url_info = api.video_trailer_url(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        succeeded = False
    else:
        playlist_url = _get_playlist_url(url_info)
        if playlist_url is None:
            succeeded = False
        else:
            listitem.set_path(playlist_url)

    plugin.resolve_url(listitem.get_item(), succeeded)


@plugin.route('/favorites_add')
def favorites_add():
    clip_id = plugin.params.clip_id

    try:
        api = TVZavr()
        api.user_favorites_add(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('Successfully added to \'Favorites\''))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.route('/favorites_rem')
def favorites_rem():
    clip_id = plugin.params.clip_id

    try:
        api = TVZavr()
        api.user_favorites_rem(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('Successfully removed from \'Favorites\''))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.route('/favorites_rem_all')
def favorites_rem_all():
    try:
        api = TVZavr()
        api.user_favorites_rem_all()
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('\'Favorites\' successfully cleared'))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.route('/history_rem')
def history_rem():
    clip_id = plugin.params.clip_id

    try:
        api = TVZavr()
        api.user_history_rem(clip_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('Successfully removed from \'Viewed\''))
        xbmc.executebuiltin('Container.Refresh()')


@plugin.route('/history_rem_all')
def history_rem_all():
    try:
        api = TVZavr()
        api.user_history_rem_all()
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
    else:
        plugin.dialog_notification_info(_('\'Viewed\' successfully cleared'))
        xbmc.executebuiltin('Container.Refresh()')


def _listitems(items, pages=None, category=None, client_ctx=None):
    use_atl_names = _use_atl_names()

    ext_dir_params = {}
    ext_item_params = {}
    if use_atl_names:
        ext_dir_params['atl'] = 1
        ext_item_params['strm'] = 1

    default_rating = _get_rating_source()

    for item in items:

        video_info = VideoInfo(item, atl_names=use_atl_names)
        listitem = ListItem(video_info, default_rating, category)

        if video_info.mediatype in ['movie', 'episode']:
            url = plugin.url_for('play_video', clip_id=listitem.clip_id, **ext_item_params)
        elif video_info.mediatype == 'tvshow':
            url = plugin.url_for('seasons', clip_id=listitem.clip_id, **ext_dir_params)
        elif video_info.mediatype == 'season':
            if listitem.season_id is not None:
                url = plugin.url_for('episodes', clip_id=listitem.clip_id, season_id=listitem.season_id,
                                     **ext_dir_params)
            else:
                url = plugin.url_for('episodes_without_season', clip_id=listitem.clip_id, **ext_dir_params)

        listitem.set_url(url)

        yield listitem.get_item()

    if pages is not None:
        if pages['prev'] is not None:
            url = plugin.url_for(pages['action'], **pages['prev'])
            listitem = {'label': _('Previous page...'),
                        'fanart': plugin.fanart,
                        'is_folder': True,
                        'url': url,
                        'properties': {'SpecialSort': 'bottom'},
                        'content_lookup': False,
                        }
            yield listitem

        if pages['next'] is not None:
            url = plugin.url_for(pages['action'], **pages['next'])
            listitem = {'label': _('Next page...'),
                        'fanart': plugin.fanart,
                        'is_folder': True,
                        'url': url,
                        'properties': {'SpecialSort': 'bottom'},
                        'content_lookup': False,
                        }
            yield listitem


@plugin.mem_cached(30)
def _catalog_navigation_menu():
    return TVZavr().catalog_navigation_menu()


def _catalog_items():
    try:
        catalog_items = _catalog_navigation_menu()
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        catalog_items = []

    movie_icon = plugin.get_image('DefaultMovies.png')
    tvshow_icon = plugin.get_image('DefaultTVShows.png')

    for item in catalog_items:
        is_tvshow = (item['category'] == '675')

        yield {'category': item['category'],
               'title': item['title'],
               'icon': tvshow_icon if is_tvshow else movie_icon,
               'content': 'tvshows' if is_tvshow else 'movies',
               }


def _catalog_history_items():
    favirote_icon = plugin.get_image('DefaultFavourites.png')

    yield {'category': 'favorites',
           'title': _('Favorites'),
           'icon': favirote_icon,
           'content': 'movies',
           }

    yield {'category': 'purchased',
           'title': _('Purchased'),
           'icon': favirote_icon,
           'content': 'movies',
           }

    yield {'category': 'viewed',
           'title': _('Viewed'),
           'icon': favirote_icon,
           'content': 'movies',
           }


def _catalog_group_items():
    try:
        group_items = TVZavr().catalog_groups()
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e)
        group_items = []

    movie_icon = plugin.get_image('DefaultMovies.png')

    for item in group_items:
        yield {'client_ctx': '{0}'.format(item['clip_group__client_ctx']),
               'title': item['clip_group__name'],
               'icon': movie_icon,
               'content': 'movies',
               'counter': item['counter'],
               }


@plugin.mem_cached(180)
def _catalog_info(category=None, client_ctx=None):
    if category is not None:
        for catalog_item in _catalog_items():
            if category == catalog_item['category']:
                return catalog_item

        for catalog_item in _catalog_history_items():
            if category == catalog_item['category']:
                return catalog_item

    if client_ctx is not None:
        for catalog_item in _catalog_group_items():
            if client_ctx == catalog_item['client_ctx']:
                return catalog_item


def _get_playlist_url(url_info):
    import m3u8

    video_url = None
    user_id = plugin.get_setting('customer_uuid') or 'NULL'
    try:
        api = TVZavr()
        playlist_url = api.get_playlist_url(url_info['url'], url_info['uuid'], user_id)
    except (TVZavrError, simplemedia.WebClientError) as e:
        plugin.notify_error(e, True)
    else:

        qualities = [240, 360, 480, 720, 1080, 2160]
        video_quality = plugin.get_setting('video_quality')
        quality = qualities[video_quality]

        variant_m3u8 = m3u8.load(playlist_url)

        for playlist in variant_m3u8.playlists:

            resolution = playlist.stream_info.resolution
            if resolution is not None \
                    and (video_url is None or resolution[1] <= quality):
                video_url = playlist.base_uri + playlist.uri

        return video_url


def _get_pages(page_params, offset, limit, total, action):
    # Parameters for previous page
    if offset >= limit:
        prev_offset = offset - limit
        if prev_offset > 0:
            prev_page = {'offset': prev_offset,
                         'limit': limit,
                         }
            prev_page.update(page_params)
        else:
            prev_page = page_params
    else:
        prev_page = None

    # Parameters for next page
    next_offset = offset + limit
    if total > next_offset:
        next_page = {'offset': next_offset,
                     'limit': limit,
                     }
        next_page.update(page_params)
    else:
        next_page = None

    pages = {'action': action,
             'prev': prev_page,
             'next': next_page,
             }

    return pages


def _get_rating_source():
    rating_source = plugin.get_setting('video_rating')
    if rating_source == 0:
        source = 'kinopoisk'
    elif rating_source == 1:
        source = 'imdb'
    else:
        source = 'tvzavr'

    return source


def _use_atl_names():
    return plugin.params.get('atl', '') == '1' \
           or plugin.get_setting('use_atl_names')


def _get_device():
    os_name = platform.system()
    if os_name == 'Linux':
        if xbmc.getCondVisibility('system.platform.android'):
            os_name = 'Android'

    device = '{0} (Kodi {1})'.format(os_name, plugin.kodi_version())

    return device


if __name__ == '__main__':
    plugin.run()
