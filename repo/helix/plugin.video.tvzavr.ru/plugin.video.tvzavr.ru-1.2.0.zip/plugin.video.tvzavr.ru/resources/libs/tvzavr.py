# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import PY3, iteritems, python_2_unicode_compatible

if PY3:
    from urllib.parse import urlencode, quote_plus, urlparse
else:
    from future.backports.urllib.parse import urlencode, quote_plus, urlparse

import sys
import math
import random
import requests

__all__ = ['TVZavrClient', 'TVZavrError']

class TVZavrError(Exception):

    def __init__(self, message, status=None):

        self.message = message
        self.status = status

        super(TVZavrError, self).__init__(self.message)

@python_2_unicode_compatible
class TVZavrClient(object):

    _api_url = 'http://api.tvzavr.ru/api'

    _plf = None
    _plf_secret = None

    def __init__(self, plf, plf_secret):

        self._plf = plf
        self._plf_secret = plf_secret

        self._client = requests.Session()

    def __str__(self):
        return '<TVZavrClient>'.format(self._plf)

    def _extract_json(self, r):
        try:
            j = r.json()
        except ValueError as e:
            raise TVZavrError(e)

        if isinstance(j, dict) \
          and j['status'] != 0:
            error = j['error']
            if isinstance(error, list):
                raise TVZavrError(error[0]['description_ru'], j['status'])
            else:
                raise TVZavrError(error['description_ru'], j['status'])

        return j

    def user_register(self):
        url = self._api_url + '/3.0/user/register'

        params = {'plf': self._plf,
                  }

        data = {'fake':1,
                }

        r = self._client.post(url, params=params, data=data)
        j = self._extract_json(r)

        return j['user_info']

    def user_login(self, login=None, password=None, user_id=None, dev_description=None):
        url = self._api_url + '/3.0/user/login'

        if login is None \
          and user_id is not None:
            params = {'plf': self._plf,
                      'user_id': user_id,
                      }

            r = self._client.get(url, params=params)

        else:
            params = {'plf': self._plf,
                      }

            data = {'email': login,
                    'password': password,
                    'dev_description': dev_description,
                    }

            r = self._client.post(url, params=params, data=data)

        j = self._extract_json(r)

        return j['dev_id']

    def user_logout(self, dev_id):
        url = self._api_url + '/3.0/user/logout'

        params = {'plf': self._plf,
                  }

        data = {'dev_id': dev_id,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_get_info(self):
        url = self._api_url + '/3.0/user/get_info'

        params = {'plf': self._plf,
                  }

        r = self._client.post(url, params=params)
        j = self._extract_json(r)

        return j['user_info']

    def user_update(self, data):
        url = self._api_url + '/3.0/user/update'

        params = {'plf': self._plf,
                  }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_get_auth_id(self, dev_description):
        url = self._api_url + '/3.0/user/get_auth_id'

        params = {'plf': self._plf,
                  'dev_description': dev_description,
                  }

        r = self._client.post(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def user_check_auth_id(self, dev_id):
        url = self._api_url + '/3.0/user/check_auth_id'

        params = {'plf': self._plf,
                  'dev_id': dev_id,
                  }

        r = self._client.post(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def user_dev_login(self, dev_id):
        url = self._api_url + '/3.0/user/dev_login'

        params = {'plf': self._plf,
                  'dev_id': dev_id,
                  }

        r = self._client.post(url, params=params)
        self._extract_json(r)

    def user_history_add(self, clip_id):
        url = self._api_url + '/3.0/user/history_add'

        params = {'plf': self._plf,
                  }

        data = {'id': clip_id,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_history_rem(self, clip_id):
        url = self._api_url + '/3.0/user/history_rem'

        params = {'plf': self._plf,
                  }

        data = {'id': clip_id,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_history_rem_all(self):
        url = self._api_url + '/3.0/user/history_rem_all'

        params = {'plf': self._plf,
                  }

        r = self._client.post(url, params=params)
        self._extract_json(r)

    def user_favorites_add(self, clip_id):
        url = self._api_url + '/3.0/user/favorites_add'

        params = {'plf': self._plf,
                  }

        data = {'id': clip_id,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_favorites_rem(self, clip_id):
        url = self._api_url + '/3.0/user/favorites_rem'

        params = {'plf': self._plf,
                  }

        data = {'id': clip_id,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def user_favorites_rem_all(self):
        url = self._api_url + '/3.0/user/favorites_rem_all'

        params = {'plf': self._plf,
                  }

        r = self._client.post(url, params=params)
        self._extract_json(r)

    def user_progress(self, clip_id, ctx='single'):
        url = self._api_url + '/3.0/user/progress'

        params = {'plf': self._plf,
                  'cid': clip_id,
                  'ctx': ctx,
                  }

        r = self._client.post(url, params=params)
        j = self._extract_json(r)

        return j['user_progress']

    def user_progress_add(self, clip_id, position, ctx):
        url = self._api_url + '/3.0/user/progress_add'

        params = {'plf': self._plf,
                  }

        data = {'cid': clip_id,
                'position': position,
                'ctx': ctx,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def catalog_navigation_menu(self):
        url = self._api_url + '/3.0/catalog/navigation_menu'

        r = self._client.get(url)
        j = self._extract_json(r)

        return j['result']['navigation_menu']

    def catalog(self, cats=None, client_ctx=None, offset=0, limit=20, sort=None):
        url = self._api_url + '/3.1/catalog/get'

        params = {'show_marks': 'true',
                  'uinfo': 'true',
                  'recomended': 'no',
                  'plf': self._plf,
                  'sort': sort,
                  'cats': cats,
                  'offset': offset,
                  'limit': limit,
                  'client_ctx': client_ctx,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def catalog_history(self, type_, offset=0, limit=20, sort=None):
        url = self._api_url + '/3.1/catalog/history'

        params = {'show_marks': 'true',
                  'uinfo': 'true',
                  'plf': self._plf,
                  'sort': sort,
                  'type': type_,
                  'offset': offset,
                  'limit': limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def catalog_groups(self):
        url = self._api_url + '/3.1/catalog/groups'

        params = {'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']


    def search_split(self, query):
        url = self._api_url + '/3.0/search/split'

        params = {'plf': self._plf,
                  'sort': 'issue',
                  'redirect': 'false',
                  'query': query,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['search_split_list']

    def video_get_info(self, clip_id):
        url = self._api_url + '/3.0/video/get_info'

        params = {'cid': clip_id,
                  'plf': self._plf,
                  'void': 'true',
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['video_data']

    def video_video_personal(self, clip_id):
        url = self._api_url + '/3.0/video/video_personal'

        params = {'cid': clip_id,
                  'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def video_rate(self, clip_id, rating):
        url = self._api_url + '/3.0/video/rate'

        params = {'plf': self._plf,
                  }

        data = {'cid=': clip_id,
                'rating': rating,
                }

        r = self._client.post(url, params=params, data=data)
        self._extract_json(r)

    def video_get_info_ext(self, clip_id, seasons_limit=None, series_limit=None):
        url = self._api_url + '/3.1/video/get_info_ext'

        params = {'cid': clip_id,
                  'plf': self._plf,
                  'uinfo': 'true',
                  'seasons_limit': seasons_limit,
                  'series_limit': series_limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def video_get_seasons(self, clip_id, offset=0, limit=10, fake_seasons=False):
        url = self._api_url + '/3.0/video/get_seasons'

        params = {'cid': clip_id,
                  'offset': offset,
                  'limit': limit,
                  'fake_seasons': 'true' if fake_seasons else None,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def video_get_series(self, season_id, offset=0, limit=10):
        url = self._api_url + '/3.0/video/get_series'

        params = {'cid': season_id,
                  'offset': offset,
                  'limit': limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def video_get_childs(self, clip_id, offset=0, limit=10):
        url = self._api_url + '/3.0/video/get_childs'

        params = {'cid': clip_id,
                  'offset': offset,
                  'limit': limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']

    def video_url(self, clip_id):
        url = self._api_url + '/3.0/video/url'

        params = {'cid': clip_id,
                  'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['video']

    def video_trailer_url(self, clip_id):
        url = self._api_url + '/3.0/video/trailer_url'

        params = {'cid': clip_id,
                  'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['video']

    def service_get_settings(self):
        url = self._api_url + '/3.0/service/get_settings'

        params = {'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['settings']

    def service_get_expanded_settings(self):
        url = self._api_url + '/3.0/service/expanded_settings'

        params = {'plf': self._plf,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j['result']


    def get_playlist_url(self, url, stream_uuid, user_id):
        url_parts = urlparse(url)

        session_key = self._session(url_parts, stream_uuid, user_id)
        token = self._generate_token(session_key, url)

        path = url_parts.path.replace('/mnf.m3u8', '/v5-mnf.m3u8')

        params = {'usessionid': session_key,
                  'pageurl': 'null',
                  'token': token,
                  'platform': self._plf,
                  }

        url_parts = url_parts._replace(query=urlencode(params), path=path)

        return url_parts.geturl()

    def _session(self, url_parts, stream_uuid, user_id):

        params = {'platform': self._plf,
                  'url': stream_uuid,
                  'UserId': user_id,
                  }

        url_parts = url_parts._replace(path='/session', query=urlencode(params))
        url = url_parts.geturl()

        r = self._client.get(url)

        return r.text

    def _generate_token(self, session_key, stream_url):
        import hashlib

        random32 = self._random32()
        hash_string = '{0}{1}{2}null{3}'.format(session_key, stream_url, random32, self._plf_secret)
        return '{0}{1}'.format(random32, hashlib.sha256(hash_string.encode('utf-8')).hexdigest())

    @staticmethod
    def _random32():

        result = ''
        charsets = '0123456789abcdef'
        while(len(result) < 32):
            index = int(math.floor(random.random() * 15))
            result = result + charsets[index]
        return result
