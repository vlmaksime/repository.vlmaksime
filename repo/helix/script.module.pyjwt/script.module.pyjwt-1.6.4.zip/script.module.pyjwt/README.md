# script.module.pyjwt

pyjwt library adapted for Kodi

General Documentation for complete module can be found out 
https://github.com/jpadilla/pyjwt
