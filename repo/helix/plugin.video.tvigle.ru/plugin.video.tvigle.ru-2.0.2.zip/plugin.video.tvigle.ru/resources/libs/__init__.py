# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import os
import time
from datetime import datetime, timedelta

import requests
import simplemedia
import xbmc
from future.utils import PY3

from .tvigle import *

__all__ = ['Tvigle', 'TvigleError']

addon = simplemedia.Addon()


class TvigleWebClient(simplemedia.WebClient):

    def _run(self, func, url, **kwargs):
        try:
            r = super(TvigleWebClient, self)._run(func, url, **kwargs)
        except simplemedia.WebClientError as e:
            if isinstance(e.message, requests.HTTPError):
                r = e.message.response
            else:
                raise e
        return r


class Tvigle(TvigleClient):

    def __init__(self):

        params = {'key': 'MzFhOGJjYmVmNmNkNGViZjhiODcwNTkzODkwNTIyMTY0MmIx',
                  'name': 'tvigle_android',
                  'partner': '24',
                  'version': '2.1.8',
                  }

        super(Tvigle, self).__init__(**params)

        headers = self._client.headers
        if addon.kodi_major_version() >= '17':
            headers['User-Agent'] = xbmc.getUserAgent()

        cookie_file = os.path.join(addon.profile_dir, 'tvigle.cookies')

        self._client = TvigleWebClient(headers, cookie_file)

        self.check_device()

    def check_device(self):

        device_id = addon.get_setting('device_id')
        if not device_id:
            device_id = self.device_id()
            addon.set_setting('device_id', device_id)

        mem_token = addon.get_mem_storage('token')
        if mem_token.get('token') is None:
            try:
                init_result = self.app_init(device_id)
            except (simplemedia.WebClientError, TvigleError) as e:
                addon.notify_error(e)
                token = ''
            else:
                token = self.update_token(init_result['token'])
        else:
            token = mem_token['token']

        if token:
            headers = {'Authorization': 'Token {0}'.format(token),
                       }

            self._client.headers.update(headers)

    def check_account(self):

        if addon.get_setting('pk'):
            account_result = self.get_account()
            user_fields = self.get_user_fields(account_result)
            addon.set_settings(user_fields)

    def update_token(self, token):

        token_info = jwt.decode(token, self._key, False)

        exp = datetime.fromtimestamp(token_info['exp'])
        cur_time = datetime.now()
        if exp < cur_time + timedelta(minutes=30):
            new_exp = exp + timedelta(days=365)
            if PY3:
                token_info['exp'] = new_exp.timestamp()
            else:
                token_info['exp'] = time.mktime(new_exp.timetuple())

        user_id = addon.get_setting('pk')
        if user_id \
                and token_info.get('user_id') != user_id:
            token_info['user_id'] = user_id

        mem_token = addon.get_mem_storage('token')
        mem_token['info'] = token_info
        mem_token['token'] = self._get_token(token_info)

        return mem_token['token']

    def logout(self):

        token_info = addon.get_mem_storage('token')
        if token_info.get('token') is not None \
                and token_info['info'].get('user_id') is not None:
            del token_info['info']['user_id']
            token_info['token'] = self._get_token(token_info['info'])

    @staticmethod
    def get_user_fields(user_info=None):
        user_info = user_info or {}

        gender = user_info.get('gender') or ''
        if gender == 'female':
            gender_id = 1
        else:
            gender_id = 0

        pk = user_info.get('pk') or 0
        if pk == 0:
            is_subscribe = False
        else:
            is_subscribe = user_info.get('is_subscribe') or False

        fields = {'pk': pk,
                  'email': user_info.get('email') or '',
                  'username': user_info.get('username') or '',
                  'gender': gender_id,
                  'birth_date': user_info.get('birth_date') or '',
                  'is_subscribe': is_subscribe,
                  }

        return fields
