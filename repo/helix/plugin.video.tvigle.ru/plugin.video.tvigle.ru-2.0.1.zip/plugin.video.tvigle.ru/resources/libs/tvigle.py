# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import python_2_unicode_compatible

import requests
import math
import random

try:
    import jwt  # python pyjwt
except ImportError:
    import pyjwt as jwt  # kodi script.module.pyjwt

__all__ = ['TvigleClient', 'TvigleError', 'jwt']


class TvigleError(Exception):
    pass


@python_2_unicode_compatible
class TvigleClient(object):

    _base_url = 'https://www.tvigle.ru'

    def __init__(self, key, name, partner, version):

        self._key = key
        self._name = name
        self._partner = partner
        self._version = version

        self._client = requests.Session()

        headers = {'Content-Type': 'application/json; charset=UTF-8',
                   'Accept': 'application/json',
                   }
        self._client.headers.update(headers)

    def __del__(self):

        self._client.close()

    def __str__(self):
        return '<TvigleClient>'.format(self._plf)

    def _extract_json(self, r):
        try:
            j = r.json()
        except ValueError as e:
            raise TvigleError(e)

        if isinstance(j, dict) \
          and j.get('detail') is not None:
            raise TvigleError(j['detail'].encode('utf-8'))

        return j

    @staticmethod
    def device_id():
        result = ''
        charsets = '0123456789abcdef'
        while(len(result) < 16):
            index = int(math.floor(random.random() * 15))
            result = result + charsets[index]
        return result

    def __app_token(self, device_id):
        payload = {'app_id': self._name,
                   'device_id': device_id,
                   'version': self._version,
                   }
        return self._get_token(payload)

    def _get_token(self, payload):
        token = jwt.encode(payload, self._key)
        return token.decode('utf-8')

    def app_init(self, device_id):
        url = self._base_url + '/app_init/'

        token = self.__app_token(device_id)
        headers = {'Authorization': 'Token {0}'.format(token),
                   }

        data = {'supported_features': ['ALL_CATEGORY'],
                }

        r = self._client.post(url, json=data, headers=headers)
        j = self._extract_json(r)

        return j

    def login(self, email, password):
        url = self._base_url + '/api/login/'

        data = {'email': email,
                'password': password,
                }

        r = self._client.post(url, json=data)
        j = self._extract_json(r)

        return j

    def get_account(self):
        url = self._base_url + '/api/account/'

        r = self._client.get(url)
        j = self._extract_json(r)

        return j

    def update_account(self, data):
        url = self._base_url + '/api/account/'

        r = self._client.put(url, json=data)
        j = self._extract_json(r)

        return j

    def account_category(self, cat_id, offset=0, limit=20):
        url = self._base_url + '/api/account/{0}/'.format(cat_id)

        params = {'offset': offset,
                  'limit': limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j

    def category(self):
        url = self._base_url + '/api/category/'

        r = self._client.get(url)
        j = self._extract_json(r)

        return j['results']

    def category_product(self, cat_id, offset=0, limit=20):
        url = self._base_url + '/api/category/{0}/product/'.format(cat_id)

        params = {'offset': offset,
                  'limit': limit,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j

    def product(self, product_id):
        url = self._base_url + '/api/product/{0}/'.format(product_id)

        r = self._client.get(url)
        j = self._extract_json(r)

        return j

    def product_video(self, product_id, group_id=None, offset=0, limit=30):
        url = self._base_url + '/api/product/{0}/video/'.format(product_id)

        params = {'offset': offset,
                  'limit': limit,
                  }
        if group_id is not None:
            params['group_id'] = group_id

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j

    def product_favorite_add(self, product_id):
        url = self._base_url + '/api/product/{0}/favorite/'.format(product_id)

        r = self._client.post(url)
        j = self._extract_json(r)

        return j['is_favorite']

    def product_favorite_rem(self, product_id):
        url = self._base_url + '/api/product/{0}/favorite/'.format(product_id)

        self._client.delete(url)

    def product_search(self, keyword, offset=0, limit=30):
        url = self._base_url + '/api/product/'

        params = {'offset': offset,
                  'limit': limit,
                  'q': keyword,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j

    def video(self, video_id):
        url = self._base_url + '/api/video/{0}/'.format(video_id)

        r = self._client.get(url)
        j = self._extract_json(r)

        return j

    def video_links(self, content_id):
        url = 'https://cloud.tvigle.ru/api/play/video/{0}/'.format(content_id)

        params = {'partner_id': self._partner,
                  }

        r = self._client.get(url, params=params)
        j = self._extract_json(r)

        return j

    def video_user_settings(self, video_id):
        url = self._base_url + '/api/video/{0}/user_settings/'.format(video_id)

        r = self._client.get(url)
        j = self._extract_json(r)

        return j

    def video_user_hr(self, video_id, offset):
        url = self._base_url + '/api/video/{0}/hr/'.format(video_id)

        data = {'offset': offset,
                }

        r = self._client.post(url, json=data)
        j = self._extract_json(r)

        return j['success']
