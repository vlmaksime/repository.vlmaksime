# -*- coding: utf-8 -*-

from .blowfish import Cipher


class Blowfish(Cipher):
    
    def initCBC(self, iv=0):
        
        self.cbc_iv = bytearray()
        for i in range(8):
            self.cbc_iv.append(0)

    def encryptCBC(self, data):

        crypted = super(Blowfish, self).encrypt_cbc(data, self.cbc_iv)
        
        self.cbc_iv = b''.join(crypted)

        return self.cbc_iv
        

__all__ = ['Blowfish']
