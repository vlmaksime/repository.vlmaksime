# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
import xbmc

from .ivi import iviClient

addon = simplemedia.Addon()

__all__ = ['ivi']

class ivi(iviClient):

    def __init__(self, app_version='870'):

        super(ivi, self).__init__(app_version)

        headers = self._client.headers
        if addon.kodi_major_version() >= '17':
            headers['User-Agent'] = xbmc.getUserAgent()

        new_client = simplemedia.WebClient(headers)

        self._client = new_client
        self._client.verify = False
