# -*- coding: utf-8 -*-

from future.utils import PY2

if PY2:
    from blowfish_py2 import Blowfish
else:
    from .blowfish_py3 import Blowfish
    
__all__ = ['Blowfish']
